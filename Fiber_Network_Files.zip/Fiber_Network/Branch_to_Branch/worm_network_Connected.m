% Network of Linear Chains
function [p,t,bd_lst_con,ang_lst,All_Orient,worm_lengths,worm_diameters,con_mat]=worm_network_Connected(sim_vol,L0_avg, D0_avg, num_worm, ds, num_rand)
    rng(num_rand);
    base_Orient = [sim_vol(1),sim_vol(2),sim_vol(3),179.9,180,179.9];
    initial_weights = rand(1,6,num_worm);
    orient_weights = [initial_weights(1,1:4,:),1-initial_weights(1,4,:),initial_weights(1,6,:)]; 
    real_worm_lengths = normrnd(L0_avg,L0_avg/4,[num_worm,1]); % Use Experimental mean and deviation
    worm_nodes = round(real_worm_lengths/ds)+1;
    worm_diameters = normrnd(D0_avg,D0_avg/4,[num_worm,1]);
    
    All_Orient = {};
    p = [];
    bd_lst = [];
    ang_lst = [];
    worm_lengths = [];
    con_mat = [];
    num_con = 0;
    t=[];
    figure(1)
    hold on
    view(1,1)
    for i = 1:num_worm
        groups = [zeros(worm_nodes(i),1)]; % 'b'= 1 base, 't' = 2 tip, 'm' = 3 mobile,
        All_Orient{i}= base_Orient.*orient_weights(:,:,i); 
        orient_vec = cell2mat(All_Orient(i));
        [ploc,tloc,bd_lstloc,ang_lstloc] = worm_oriented(worm_nodes(i),ds, orient_vec);
        zmin = min(ploc(:,4));
        zmax = max(ploc(:,4));
        for l = 1:worm_nodes(i)
            if ploc(l,4) == zmin
                groups(l) = 1;          % Set base group members
            elseif ploc(l,4) == zmax
                groups(l) = 2;          % Set tip group members
            else 
                groups(l) = 3;          % Set only mobile group members
            end
        end
        if i>1
            for j = 1:worm_nodes(i)
                w_point = ploc(j,2:4);
                for k = 1:length(p)
                    point_check = p(k,2:4);
                    dx = w_point(1)-point_check(1);
                    dy = w_point(2)-point_check(2);
                    dz = w_point(3)-point_check(3);
                    dist = sqrt((dx)^2+(dy)^2+(dz)^2);
                    if dist <= ds/2
                        num_con = num_con+1;
                        worm_con = sum(worm_nodes(1:i-1,1))+j;
                        net_p_con = k;
                        con_mat = [con_mat;num_con,worm_con,net_p_con];
                        plot3([w_point(1),point_check(1)],[w_point(2),point_check(2)],[w_point(3),point_check(3)],'r-x')
                    end
                end    
            end
        end
        p = [p;ploc(:,1)+(sum(worm_nodes(1:i-1,1))),ploc(:,2:4),groups];
        bd_lst = [bd_lst;bd_lstloc(:,1)+(sum(worm_nodes(1:i-1,1)-1)),bd_lstloc(:,2:3)+(sum(worm_nodes(1:i-1,1)))];
        ang_lst = [ang_lst;ang_lstloc(:,1)+(sum(worm_nodes(1:i-1,1)-2)),ang_lstloc(:,2:4)+(sum(worm_nodes(1:i-1,1)))];
        worm_lengths = [worm_lengths, worm_nodes(i)*ds];
        plot3(ploc(:,2),ploc(:,3),ploc(:,4),'b')   
    end
    bd_lst_con = [bd_lst;length(bd_lst(:,1))+con_mat(:,1),con_mat(:,2:3)];
end
