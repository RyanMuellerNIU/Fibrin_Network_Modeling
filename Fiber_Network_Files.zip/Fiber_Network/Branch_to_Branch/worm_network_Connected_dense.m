% Network of Linear Chains
function [p,t,bd_lst,ang_lst,All_Orient,worm_lengths,worm_diameters,con_mat]=worm_network_Connected_dense(sim_vol,Exp_Data,ds,num_rand)
    rng(num_rand);
    vol_scale =1.4;
    num_branch_point = round(sim_vol(1)*sim_vol(2)*sim_vol(3)*Exp_Data(1,1));
    Avg_fiber_links = round(sim_vol(1)*sim_vol(2)*sim_vol(3)*Exp_Data(2,1));
    Avg_fiber_length = Exp_Data(3,1);
    Avg_num_node = round(Avg_fiber_length/ds)+1;
    Avg_Fiber_D = Exp_Data(4,1)+Exp_Data(4,2)*normrnd(0,1);
    worm_diameters = [];
    Max_branch_pos = [sim_vol(1),sim_vol(2),sim_vol(3)]; % The farthest possible branch location
    Min_branch_pos = [0,0,0];
    pos_weights = rand(num_branch_point,3);% The position weights based on max position
    Init_Network_Pos = pos_weights.*Max_branch_pos;
    Pre_Network_Pos = [Init_Network_Pos(:,1),Init_Network_Pos(:,2),Init_Network_Pos(:,3)];
    
    All_in_range = 0;
    Step_Count = 0;
    max_len = Exp_Data(3,1) + Exp_Data(3,2);
    min_len = Exp_Data(3,1) - Exp_Data(3,2);
    figure(1)
    title('Fibrin Network')
    while All_in_range == 0
        num_too_close = 0;
        num_target = 0;
        all_pot_bonds = {};
        for i = 1:num_branch_point %Use agent based modeling to set up initial network
            Agent_Pos = Pre_Network_Pos(i,:);
            too_close = [];
            too_far = [];
            target = [];
            pot_bonds = [];
            for j = 1:num_branch_point
                if j~=i
                    Obj_Pos = Pre_Network_Pos(j,:);
                    dx = Agent_Pos(1)-Obj_Pos(1);
                    dy = Agent_Pos(2)-Obj_Pos(2);
                    dz = Agent_Pos(3)-Obj_Pos(3);
                    cur_len = sqrt(dx^2+dy^2+dz^2);
                    if cur_len < min_len
                        too_close = [too_close;Obj_Pos];
                        num_too_close = num_too_close+1;
                    end    
                    if ((min_len<=cur_len)&&(cur_len<= max_len))
                        target = [target;Obj_Pos];
                        pot_bonds = [pot_bonds;j];
                    else
                        too_far = [too_far;Obj_Pos];
                    end    
                end
            end 
            if isempty(too_close) == 0
                mean_x = mean(too_close(:,1));   % Find the average position of the closest objects
                mean_y = mean(too_close(:,2));
                mean_z = mean(too_close(:,3));
                
                rel_x = mean_x - Agent_Pos(1);   % Find the relative position 
                rel_y = mean_y - Agent_Pos(2);
                rel_z = mean_z - Agent_Pos(3);

                rel_mag = sqrt(rel_x^2+rel_y^2+rel_z^2);      %Find the magnitude and direction
                Unit_Vec = (1/rel_mag)*([rel_x,rel_y,rel_z]); %This is the direction of the closest objects
                new_Agent_Pos = Agent_Pos - 0.3*ds*Unit_Vec;      %Move ds away from nearest objects
                if new_Agent_Pos(1)<Min_branch_pos(1) || new_Agent_Pos(1)>vol_scale*Max_branch_pos(1)
                    new_Agent_Pos(1) = Agent_Pos(1);
                end
                if new_Agent_Pos(2)<Min_branch_pos(2) || new_Agent_Pos(2)>vol_scale*Max_branch_pos(2)
                    new_Agent_Pos(2) = Agent_Pos(2);
                end
                if new_Agent_Pos(3)<Min_branch_pos(3) || new_Agent_Pos(3)>vol_scale*Max_branch_pos(3)
                    new_Agent_Pos(3) = Agent_Pos(3);
                end
                Pre_Network_Pos(i,:) = new_Agent_Pos;
            end   
            if isempty(target) == 1 
                mean_x = mean(too_far(:,1));   % Find the average position of the far objects
                mean_y = mean(too_far(:,2));
                mean_z = mean(too_far(:,3));
                
                rel_x = mean_x - Agent_Pos(1);   % Find the relative position 
                rel_y = mean_y - Agent_Pos(2);
                rel_z = mean_z - Agent_Pos(3);

                rel_mag = sqrt(rel_x^2+rel_y^2+rel_z^2);      %Find the magnitude and direction
                Unit_Vec = (1/rel_mag)*([rel_x,rel_y,rel_z]); %This is the direction of the far objects
                new_Agent_Pos = Agent_Pos + 0.3*ds*Unit_Vec;      %Move ds towards the far objects
                Pre_Network_Pos(i,:) = new_Agent_Pos;
            end    
        end
        if num_too_close == 0
            All_in_range = 1
            Exp_Network = Pre_Network_Pos; 
            for i = 1:num_branch_point %Use agent based modeling to set up initial network
                Agent_Pos = Pre_Network_Pos(i,:);
                too_close = [];
                too_far = [];
                target = [];
                pot_bonds = [];
                for j = 1:num_branch_point
                    if j~=i
                        Obj_Pos = Pre_Network_Pos(j,:);
                        dx = Obj_Pos(1)-Agent_Pos(1);
                        dy = Obj_Pos(2)-Agent_Pos(2);
                        dz = Obj_Pos(3)-Agent_Pos(3);
                        cur_len = sqrt(dx^2+dy^2+dz^2);
                        if cur_len < min_len
                            too_close = [too_close;Obj_Pos];
                            num_too_close = num_too_close+1;
                        end    
                        if ((min_len<=cur_len)&&(cur_len<= max_len))
                            target = [target;Obj_Pos];
                            pot_bonds = [pot_bonds;[j,cur_len,Obj_Pos]];
                        else
                            too_far = [too_far;Obj_Pos];
                        end    
                    end
                end
                all_pot_bonds(i) = {pot_bonds};
            end 
        end
        scatter3(Pre_Network_Pos(:,1),Pre_Network_Pos(:,2),Pre_Network_Pos(:,3),'red','filled')
        pause(0.01)
        Step_Count = Step_Count + 1;
        if Step_Count > 100000
            break
        end    
    end
    Network = zeros([num_branch_point,4]);
    for i=1:num_branch_point
        Network(i,:) = [i,Exp_Network(i,:)];
    end    
    
    p = Network;
    All_Orient = {};
    bd_lst = [];
    ang_lst = [];
    worm_lengths = [];
    con_mat = [];
    num_con = 0;
    t=[];
    figure(1)
    hold on
    num_fibers = 0;
    Branch_ID = 1;
    while num_fibers < Avg_fiber_links  
        Start_Node = Branch_ID;
        pot_bonds = cell2mat(all_pot_bonds(Branch_ID));
        num_pot_bond = floor(1+(length(pot_bonds)-1)*rand());
        End_Node = pot_bonds(num_pot_bond,1);

        [ploc,tloc,bd_lstloc,ang_lstloc,L] = worm_density(Avg_num_node,Network,Start_Node,End_Node);
        %plot3(ploc(:,2),ploc(:,3),ploc(:,4),'b-')    
        pause(.01)
        num_fibers = num_fibers+1;
        Branch_ID = Branch_ID +1;
        if Branch_ID > num_branch_point
            Branch_ID = 1;
        end    
        %p_global = [[ploc(1,1);(ploc(2:end-1,1)+length(p(:,1))-1);ploc(end,1)],ploc(1:end,2:4)];
        p_global = [(ploc(2:end-1,1)+length(p(:,1))-1),ploc(2:end-1,2:4)];

        bd_lst_global = [bd_lstloc(1,2),bd_lstloc(1,3)-1+length(p);
                         bd_lstloc(2:end-1,2)-1+length(p),bd_lstloc(2:end-1,3)-1+length(p);
                         bd_lstloc(end,2)-1+length(p),bd_lstloc(end,3)];
        
        ang_lst_global = [ang_lstloc(1,2),ang_lstloc(1,3)-1+length(p), ang_lstloc(1,4)-1+length(p);
                          ang_lstloc(2:end-1,2)-1+length(p), ang_lstloc(2:end-1,3)-1+length(p), ang_lstloc(2:end-1,4)-1+length(p);
                          ang_lstloc(end,2)-1+length(p), ang_lstloc(end,3)-1+length(p), ang_lstloc(end,4)];

        p = [p;p_global]; %Good to Go
        bd_lst = [bd_lst;bd_lstloc(:,1)+length(bd_lst),bd_lst_global]; %Good to go
        
        ang_lst = [ang_lst;ang_lstloc(:,1)+length(ang_lst),ang_lst_global];
        worm_lengths = [worm_lengths, L/(Avg_num_node-1)];
        %plot3(ploc(:,2),ploc(:,3),ploc(:,4),'b')
    end

    %figure(7)
    %hold on
    %view([37.5 30])
    %title('Initial Branch Locations')
    %scatter3(Init_Network_Pos(:,1),Init_Network_Pos(:,2),Init_Network_Pos(:,3),'red')
    %xlim([0,vol_scale*sim_vol(1)])
    %ylim([0,vol_scale*sim_vol(2)])
    %zlim([0,vol_scale*sim_vol(3)])

    %figure(8)
    %hold on
    %view([37.5 30])
    %title('Final Branch Locations')
    %scatter3(Exp_Network(:,1),Exp_Network(:,2),Exp_Network(:,3),'red')
    %xlim([0,vol_scale*sim_vol(1)])
    %ylim([0,vol_scale*sim_vol(2)])
    %zlim([0,vol_scale*sim_vol(3)])
end
