clc
clf
clear all;
%% Set Calculation Parameters
%----- normalized value ---------------------%
% dt = 1e-6; % s
dx = .5e-6;%0.5e-6;%1e-6; % m
tau=1;%0.95;% best accuracy
vis=1e-3; %pa*s
rho=1e3;%kg/m^3
dt=(tau-0.5)/3*dx^2*rho/vis;
%-- palabos incompressible parameters--------%
u_phy = 5e-3; % m/s
u_max = u_phy/(dx/dt);% U_physical = 1
Re =  dx*u_phy/(vis/rho);
Nreso=1; % dx as 1, 
nu_lb = Nreso*u_max/Re;
dm = rho*dx*dx*dx; % water mass
epsilon = dm*(dx/dt)^2; % energy units
kBT=1.3806e-23*296; % thermal energy
r_p=100e-9; % radius of np
T = kBT/epsilon;

fprintf('Re %e\n',Re);
fprintf('Nreso %d\n',Nreso);
fprintf('u_Max %e\n',u_max);
fprintf('dx %e\n',dx);
fprintf('dt %e\n',dt);
fprintf('scaled temperature %e\n',T);

%% Set Network Parameters
% ---- Simulation Volume Dimensionless Units -----%
% Based on density 

xlo = 0; xhi = 150; % Initial Horizontal Space in lammps 
ylo = 0; yhi = 150;
zlo = 0; zhi = 150; % Initial Height of the Sim space 

vol_factor = 1;
sim_vol = [(xhi-xlo)*vol_factor,(yhi-ylo)*vol_factor,(zhi-zlo)*vol_factor];

Branch_Point_Density = 1.2/((10^3)*(1e-6)^3)*(dx^3); %per 10^3 um^3 CONVERTS to Brach_points/NU_vol
Branch_Point_IC = 0.7/((10^3)*(1e-6)^3)*(dx^3); % +- Brach_points/NU_vol
Fiber_Density = 4.2/((10^3)*(1e-6)^3)*(dx^3); % per 10^3 um^3
Fiber_Density_IC = 0.2/((10^3)*(1e-6)^3)*(dx^3); % per 10^3 um^3
Dist_Branch_Point = 23*(1e-6)/dx; % Converts um to NU length
Dist_Branch_Point_IC = 9*(1e-6)/dx; % Converts um to NU length
Fiber_D = 286*(1e-9)/dx; % Converts nm to NU Diameter
Fiber_D_IC = 48*(1e-9)/dx; % % Converts nm to NU Diameter

pL=0.8e-9;   % persistence length based on houser paper (Should be scaled with changing Diameter)
kBT=1.3806e-23*296;
ds = 10; % if dx = 0.5 then ds = 1 (ds = #*dx/dx)

num_rand = 3;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initialize WLC parameters Using experimental data

% Labels: li --> Ligated , unli --> Unligated

l_0 = 10e-6; % Initial length used by Houser paper

% Unligated Fibers
A_unli = 3.2265438863137044e-09;
l_m_unli = 36.93568656134975e-06; % Maximum length of WLC (Including stretch)
k_p_unli = 1.8696547567965926e-19; %repulsion coeff

%since A = N*(kBT)/pL
N_unli = round((A_unli*pL)/kBT); %round to nearest whole link (PARALLEL)
x0_unli=l_0/l_m_unli; 
Kwlc_unli=N_unli*kBT/pL*dt^2/dm/dx; % scale kwlc to lb units 

% Ligated Fibers
A_li = 2.2186848058111795e-09; 
l_m_li = 33.56389754487316e-06;% Maximum length of WLC (Including stretch)
k_p_li = 1.1922356902864575e-19;

%since A = N*(kBT)/pL
N_li = round((A_li*pL)/kBT); %round to nearest whole link (PARALLEL)
x0_li=l_0/l_m_li; 
Kwlc_li=N_li*kBT/pL*dt^2/dm/dx; % scale kwlc to lb units 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initialize the Network Structure Using the worm_network Function
Exp_Data = [Branch_Point_Density,Branch_Point_IC;Fiber_Density,Fiber_Density_IC;Dist_Branch_Point,Dist_Branch_Point_IC;Fiber_D,Fiber_D_IC];

[p,t,bd_lst,ang_lst,All_Orient,worm_lengths,worm_diameters,con_mat]=  worm_network_Connected_dense(sim_vol,Exp_Data,ds,num_rand);

%p2 = [p(:,1)+length(p(:,1)),p(:,2),p(:,3),p(:,4)+50];
%bd_lst_2 = [bd_lst(:,1)+length(bd_lst(:,1)),bd_lst(:,2)+length(p(:,1)),bd_lst(:,3)+length(p(:,1))];
%ang_lst_2 = [ang_lst(:,1)+length(ang_lst(:,1)),ang_lst(:,2)+length(p(:,1)),ang_lst(:,3)+length(p(:,1)),ang_lst(:,4)+length(p(:,1))];

%p3 = [p2(:,1)+length(p(:,1)),p(:,2),p(:,3),p2(:,4)+50];
%bd_lst_3 = [bd_lst_2(:,1)+length(bd_lst(:,1)),bd_lst_2(:,2)+length(p(:,1)),bd_lst_2(:,3)+length(p(:,1))];
%ang_lst_3 = [ang_lst_2(:,1)+length(ang_lst(:,1)),ang_lst_2(:,2)+length(p(:,1)),ang_lst_2(:,3)+length(p(:,1)),ang_lst_2(:,4)+length(p(:,1))];

%r_p = 8e-6/dx;
%[p_cell,t]=Init3D_div(1,0.25); % works for uniformmesh
%p_cell=RBC_x(p_cell,2);

p_cell=p_cell*r_p; 
p4 = [];
for i = 1: length(p_cell(:,1))
    p4(i,:) = [i+3*length(p),p_cell(i,1)+100,p_cell(i,2)+100,p_cell(i,3)+25];
end
p41 = [p4;p4(:,1)+length(p_cell(:,1)),p_cell(:,1)+50,p_cell(:,2)+100,p_cell(:,3)+30];
p42 = [p41;p4(:,1)+length(p_cell(:,1)),p_cell(:,1)+20,p_cell(:,2)+100,p_cell(:,3)+30];
p43 = [p42;p4(:,1)+length(p_cell(:,1)),p_cell(:,1)+80,p_cell(:,2)+100,p_cell(:,3)+30];
p44 = [p43;p4(:,1)+length(p_cell(:,1)),p_cell(:,1)+130,p_cell(:,2)+120,p_cell(:,3)+30];
p45 = [p44;p4(:,1)+length(p_cell(:,1)),p_cell(:,1)+140,p_cell(:,2)+80,p_cell(:,3)+30];
p46 = [p45;p4(:,1)+length(p_cell(:,1)),p_cell(:,1)+50,p_cell(:,2)+20,p_cell(:,3)+80];
p47 = [p46;p4(:,1)+length(p_cell(:,1)),p_cell(:,1)+100,p_cell(:,2)+40,p_cell(:,3)+80];
p48 = [p47;p4(:,1)+length(p_cell(:,1)),p_cell(:,1)+20,p_cell(:,2)+180,p_cell(:,3)+80];
p49 = [p48;p4(:,1)+length(p_cell(:,1)),p_cell(:,1)+80,p_cell(:,2)+20,p_cell(:,3)+80];
p410 = [p49;p4(:,1)+length(p_cell(:,1)),p_cell(:,1)+130,p_cell(:,2)+120,p_cell(:,3)+80];
p411 = [p410;p4(:,1)+length(p_cell(:,1)),p_cell(:,1)+140,p_cell(:,2)+80,p_cell(:,3)+80];
p412 = [p411;p4(:,1)+length(p_cell(:,1)),p_cell(:,1)+30,p_cell(:,2)+40,p_cell(:,3)+80];
p413 = [p412;p4(:,1)+length(p_cell(:,1)),p_cell(:,1)+60,p_cell(:,2)+100,p_cell(:,3)+80];
p = [p;p2;p3;p411];
bd_lst = [bd_lst;bd_lst_2;bd_lst_3];
ang_lst = [ang_lst;ang_lst_2;ang_lst_3];



%% Create Bond Types
x0 = l_0/l_m_unli; % or l_m_li
bd_types = [];
%L = L0_avg;
for i = 1:3*length(worm_lengths)
    L = ds;
    %Kwlc=worm_diameters(i)*kBT/pL*dt^2/dm/dx; % scale kwlc to lb units 
    Kwlc=N_unli*kBT/pL*dt^2/dm/dx;
    KrpW=Kwlc*(0.25/(1-x0)^2-0.25+x0)*(L^2); % for wlc model
    bd_types = [bd_types;i,Kwlc,L,x0,KrpW];
end

%% Create Groups:
group_tip = [];
group_mobile =[];
group_base = [];
for i = 1:length(p(:,1))
    atom = p(i,:);
    if atom(3) > 0.95*max(p(:,3))
        group_tip = [group_tip,i];
        group_mobile = [group_mobile,i];
    elseif 0.05*max(p(:,3)) < atom(3) && atom(3) < 0.95*max(p(:,3))
        group_mobile = [group_mobile,i];
    else
        group_base = [group_base,i];
    end    
end
%% Create Intput File

% write output
name='in.worm_net_density'
fid = fopen(name,'w+');
fprintf(fid,'lammps cell input\n');
nAt=size(p,1);
fprintf(fid,'%d atoms\n', nAt);
nB=size(bd_lst,1);
fprintf(fid,'%d bonds\n', nB);
nAn=size(ang_lst,1);
fprintf(fid,'%d angles\n', nAn);

nat=1;
fprintf(fid,'%d atom types\n', nat);
nbt=3*length(worm_lengths);                 %for now, 1 (will need to change)
fprintf(fid,'%d bond types\n', nbt);
nangt=1;
fprintf(fid,'%d angle types\n', nangt);%for now, 1 (will need to change)

fprintf(fid,'%g %g xlo xhi\n',xlo,1.5*xhi);
fprintf(fid,'%g %g ylo yhi\n',ylo,1.5*yhi);
fprintf(fid,'%g %g zlo zhi\n\n',zlo,150);

fprintf(fid,'Masses\n\n');
m=rho*4/3*pi*r_p^3/dm;
fprintf(fid,'%d %g\n',1,m);
fprintf(fid,'\n');

fprintf(fid,'Bond Coeffs\n\n');
for i=1:3*length(worm_lengths)
    fprintf(fid,'%d %g %g %g %g\n ',bd_types(i,1),bd_types(i,2),bd_types(i,3),bd_types(i,4),bd_types(i,5));
end
fprintf(fid,'\n');

fprintf(fid,'Angle Coeffs\n\n');%Cosine
for i=1:nangt
    %fprintf(fid,'%d %g %d %d\n',i,K,d,n);
    fprintf(fid,'%d %g\n',i,pL/dx); % High stiffness
end
fprintf(fid,'\n');

%fprintf(fid,'Angle Coeffs\n\n'); %Cosine/Shift
%for i=1:nangt
    %fprintf(fid,'%d %g %d %d\n',i,K,d,n);
 %   fprintf(fid,'%d %g %d\n',i,pL/dx,180); % High stiffness
%end
%fprintf(fid,'\n');

fprintf(fid,'Atoms\n\n');
% molecular type: aID, mID, aTy, x, y, z
for i=1:nAt
    fprintf(fid,'%d %d %d %g %g %g\n',p(i,1),1,1,p(i,2),p(i,3),p(i,4));
end
fprintf(fid,'\n');

fprintf(fid,'Bonds\n\n');
% WLC bID, bType, Atom1, Atom2
bd_number = 1;
for i=1:3*length(worm_lengths)
    for j = 1:round(Exp_Data(3,1)/ds)+1-1
        fprintf(fid,'%d %d %d %d\n',bd_lst(bd_number,1),i,bd_lst(bd_number,2),bd_lst(bd_number,3)); %This needs to change with bd type
        bd_number = bd_number+1;
    end
end
fprintf(fid,'\n');

fprintf(fid,'Angles\n\n');
% angleID, aType, atom1,2,3
for i=1:nAn
    fprintf(fid,'%d %d %d %d %d\n',ang_lst(i,1),1,ang_lst(i,2),ang_lst(i,3),ang_lst(i,4)); %Angle type needs to change
end
fprintf(fid,'\n');

fclose(fid);