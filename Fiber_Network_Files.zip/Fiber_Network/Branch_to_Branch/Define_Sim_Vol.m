function [Sim_Vol,Unsafe_Regions]=Define_Sim_Vol(Total_Vol,Cell_Centers,r_p)
    Sim_Vol = Total_Vol(1)*Total_Vol(2)*Total_Vol(3);
    safety_cube_lim = 1.5*r_p;
    vol_per_cube = (2*safety_cube_lim)^3;
    Unsafe_Regions = {};
    for i = 1: length(Cell_Centers(:,1))
        x_bound = [Cell_Centers(i,1)-safety_cube_lim,Cell_Centers(i,1)+safety_cube_lim];
        y_bound = [Cell_Centers(i,2)-safety_cube_lim,Cell_Centers(i,2)+safety_cube_lim];
        z_bound = [Cell_Centers(i,3)-safety_cube_lim,Cell_Centers(i,3)+safety_cube_lim];
        Unsafe_Regions(i) = {[x_bound;y_bound;z_bound]};
        Sim_Vol = Sim_Vol - vol_per_cube;
    end    