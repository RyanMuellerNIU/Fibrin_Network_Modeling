% linear chain
function [p,t,bd_lst,ang_lst,L]=worm_density(N,Network,S_node,E_node)
Start = Network(S_node,:);
End = Network(E_node,:);
L = sqrt((End(2)-Start(2))^2+(End(3)-Start(3))^2+(End(4)-Start(4))^2);
p=zeros(N,4);
bd_lst=zeros(N-1,3);%bond_list
ang_lst=zeros(N-2,4);%angle_list

%set worm location
ds = L/(N-1);
dz = ds*((End(4)-Start(4))/L);
dy = ds*((End(3)-Start(3))/L);
dx = ds*((End(2)-Start(2))/L);

p(1,:) = Start;
p(N,:) = End;
for i = 2:N-1
    p(i,1)=i;
    p(i,2)=Start(2)+(i-1)*dx;
    p(i,3)=Start(3)+(i-1)*dy;
    p(i,4)=Start(4)+(i-1)*dz;
end

for i=1:N-1
  if i == 1
    bd_lst(i,1)=i;
    bd_lst(i,2)=Start(1);
    bd_lst(i,3)=i+1;
  elseif i == N-1
    bd_lst(i,1)=i;
    bd_lst(i,2)=i;
    bd_lst(i,3)=End(1);
  else
    bd_lst(i,1)=i;
    bd_lst(i,2)=i;
    bd_lst(i,3)=i+1;
  end    
end

for i=1:N-2
    if i == 1  
        ang_lst(i,1)=i;
        ang_lst(i,2)=Start(1);
        ang_lst(i,3)=i+1;
        ang_lst(i,4)=i+2;
    elseif i == N-2
        ang_lst(i,1)=i;
        ang_lst(i,2)=i;
        ang_lst(i,3)=i+1;
        ang_lst(i,4)=End(1);
    else
        ang_lst(i,1)=i;
        ang_lst(i,2)=i;
        ang_lst(i,3)=i+1;
        ang_lst(i,4)=i+2;    
    end
end
t=[];
end
