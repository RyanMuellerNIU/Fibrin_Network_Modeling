% Network of Linear Chains
function [p,t,bd_lst,ang_lst,All_Orient,worm_lengths,worm_diameters,worm_nodes]=worm_network_self_assem(sim_vol,L0_avg, Diameter_info, num_worm, ds, Branch_Dist, num_rand)
    rng(num_rand);                              % Set the random number generator seed
    Mean_Diameter = Diameter_info(1);           % Set the mean fiber diameter 
    Diameter_std_dev = Diameter_info(2);        % Set the fiber standard deviation
    Monomer_Diam = Diameter_info(3);            % Set the monomer diameter
    worm_diameters = normrnd(Mean_Diameter,Diameter_std_dev,[num_worm,1]);  % Create a randomly assigned normal sistribution of fiber diameters
    worm_diameters = [worm_diameters, round((worm_diameters/Monomer_Diam).^2)]; % Calculate how many monomers are in parallel within the fibers

    base_Orient = [sim_vol(1),sim_vol(2),sim_vol(3),179.9,180,179.9]; % Sets the maximum values for the orientations
                                                                      % [Max_x, Max_y, Max_z,Max_ang_x,Max_ang_y,Max_ang_z]
    initial_weights = rand(1,6,num_worm);   % Sets the random weights for all worms
    orient_weights = [initial_weights(1,1:4,:),1-initial_weights(1,4,:),initial_weights(1,6,:)]; % Adjusts the y angle component to relate with the x angle component
    real_worm_lengths = normrnd(L0_avg,L0_avg/4,[num_worm,1]); % Use Experimental mean and deviation
    worm_nodes = round(real_worm_lengths/ds)+1;      % Calculate the number of nodes required for each fiber when spaced by ds
    Branch_Dist = round(Branch_Dist);                % Estimate the mean branch distance in unitless dimensions
    Num_Nodes_Per_Branch = floor(Branch_Dist/ds)+1;  % Set how many nodes will exist between branch points
    
    All_Orient = {};    % Create an empty cell to store the orientation information for each worm
    p = [];             % create arrays for all other WLC fiber information
    bd_lst = [];
    ang_lst = [];
    worm_lengths = [];
    t=[];               % This is an empty tringle array... it isn't used
    figure(1)           % open a figure for displaying the initial fiber network
    hold on
    view(1,1)
    for i = 1:num_worm  % loop for each worm
        groups = [ones(worm_nodes(i),1)]; % 'b'= 2 branch, 'n' = 1 none, (Assume all nodes aren't branches initially)
        All_Orient{i}= base_Orient.*orient_weights(:,:,i); % Mujltiply the base orientation by the weights to generate the random fiber orientions
        orient_vec = cell2mat(All_Orient(i));              % convert the current cell to an array for use in the worm_oriented function 
        
        [ploc,tloc,bd_lstloc,ang_lstloc] = worm_oriented(worm_nodes(i),ds, orient_vec); % This function outputs a oriented fiber to the specified inputs
        
        j =0;   % set the node number to zero
        while j < worm_nodes(i)       % While the current node is within the current worm
            groups(1+j,1) = 2;        % Set the atom type to branch
            j=j+Num_Nodes_Per_Branch; % Increase j to account for the branch distance (number of nodes between branches)  
        end
        p = [p;ploc(:,1)+(sum(worm_nodes(1:i-1,1))),ploc(:,2:4),groups];    % Add the new worm's information to the global lists
        bd_lst = [bd_lst;bd_lstloc(:,1)+(sum(worm_nodes(1:i-1,1)-1)),bd_lstloc(:,2:3)+(sum(worm_nodes(1:i-1,1)))];
        ang_lst = [ang_lst;ang_lstloc(:,1)+(sum(worm_nodes(1:i-1,1)-2)),ang_lstloc(:,2:4)+(sum(worm_nodes(1:i-1,1)))];
        worm_lengths = [worm_lengths, worm_nodes(i)*ds];   % Record the worm length for each worm using the number of segments and segment length ds 
        plot3(ploc(:,2),ploc(:,3),ploc(:,4),'b-')          % plot the current worm
        for k = 1:length(ploc(:,1)) % loop for all nodes in the current worm 
            if p(k,5) == 2  % if The node is a branch
               plot3(ploc(k,2),ploc(k,3),ploc(k,4),'rx')  % plot a red x for branches 
            end    
        end
    end
    %Adjust the positions to make all points positive:
    x_bounds = [min(p(:,2)),max(p(:,2))];
    y_bounds = [min(p(:,3)),max(p(:,3))];
    z_bounds = [min(p(:,4)),max(p(:,4))];
    if x_bounds(1) < 0
        p(:,2) = p(:,2) + abs(x_bounds(1));
    end
    if y_bounds(1) < 0
        p(:,3) = p(:,3) + abs(y_bounds(1));
    end
    if z_bounds(1) < 0
        p(:,4) = p(:,4) + abs(z_bounds(1));
    end
end
