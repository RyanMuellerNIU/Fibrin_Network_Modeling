clc
clf
clear all;
%% Set Calculation Parameters
%----- normalized value ---------------------%
% dt = 1e-6; % s
dx = .25e-6;%0.5e-6;%1e-6; % m
tau=1;%0.95;% best accuracy
vis=1e-3; %pa*s
rho=1e3;%kg/m^3
dt=(tau-0.5)/3*dx^2*rho/vis;
%-- palabos incompressible parameters--------%
u_phy = 5e-3; % m/s
u_max = u_phy/(dx/dt);% U_physical = 1
Re =  dx*u_phy/(vis/rho);
Nreso=1; % dx as 1, 
nu_lb = Nreso*u_max/Re;
dm = rho*dx*dx*dx; % water mass
epsilon = dm*(dx/dt)^2; % energy units
kBT=1.3806e-23*296; % thermal energy
T = kBT/epsilon;

fprintf('Re %e\n',Re);
fprintf('Nreso %d\n',Nreso);
fprintf('u_Max %e\n',u_max);
fprintf('dx %e\n',dx);
fprintf('dt %e\n',dt);
fprintf('scaled temperature %e\n',T);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Set Network Parameters
% ---- Simulation Volume Dimensionless Units -----%

xlo = 0; xhi = 120; % Volume of fiber network generation space
ylo = 0; yhi = 120;
zlo = 0; zhi = 120; % Height of the Sim space 

vol_factor = 1;  % This adjusts how spaced out the fibers are initially 

L_Scale = 4;         % Scale from unit fiber
l_0 = L_Scale*10e-6; % Mean Initial length of WLC [m]
ds = 2*dx;        % WLC Link Length

num_rand = 34; % Randomization Seed (Positive Int)

% Create pL for the coarse-grained simulation
pL_mon=0.8e-9;              % Mean persistence length (FOR MONOMER) [m]
L_mon = 45e-9;              % Length of monomer [m]
Show_graph = true;

[A_Vals,l_m_Vals,k_p_Vals,kb] = fiber_parameter_generator(kBT,pL_mon,L_mon,ds,Show_graph);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initialize WLC parameters Using experimental data

% Labels: li --> Ligated , unli --> Unligated

%Fiber density and other information
Branch_Point_Density = 1.2/((10^3)*(1e-6)^3)*(dx^3); %per 10^3 um^3 CONVERTS to Brach_points/NU_vol
Branch_Point_IC = 0.7/((10^3)*(1e-6)^3)*(dx^3); % +- Brach_points/NU_vol
Fiber_Density = 4.2/((10^3)*(1e-6)^3)*(dx^3); % per 10^3 um^3
Fiber_Density_IC = 0.2/((10^3)*(1e-6)^3)*(dx^3); % per 10^3 um^3
Dist_Branch_Point = 23*(1e-6)/dx; % Converts um to NU length
Dist_Branch_Point_IC = 9*(1e-6)/dx; % Converts um to NU length
Fiber_D = [286*(1e-9)/dx , 48*(1e-9)/dx, 6.9*(1e-9)/dx]; % % Converts nm to NU Diameter [mean fiber diameter, diameter variance, monomer diameter]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initialize the Network Structure Using the worm_network Function
sim_vol = [(xhi-xlo)*vol_factor,(yhi-ylo)*vol_factor,(zhi-zlo)*vol_factor];

init_wall_dist = 10;

num_worm = round(xhi*yhi*zhi*Fiber_Density);

L0_avg = l_0/dx;
[p,t,bd_lst,ang_lst,All_Orient,worm_lengths,worm_diameters,worm_nodes] = worm_network_self_assem(sim_vol,L0_avg, Fiber_D, num_worm, ds/dx, Dist_Branch_Point, num_rand);

sim_shift = [init_wall_dist,init_wall_dist,init_wall_dist];

figure(2)
hold on
title('Simulation Volume Shifted')
plot3(p(:,2)+sim_shift(1),p(:,3)+sim_shift(2),p(:,4)+sim_shift(3),'b-o')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Create Bond and Angle Types
A = A_Vals(1);          %For unligated fibers use 1 and for ligated fibers, use 2
l_m = l_m_Vals(1);
k_p = k_p_Vals(1);

x0 = l_0/(L_Scale*l_m); % or l_m_li
bd_types = [];
Bend_Stiff = [];
for i = 1:num_worm
    L = ds/dx;
    L_tot = worm_nodes(i)*ds;    %total length of the fiber [m]

    pL = kb*L_tot/kBT;              %pL of the entire fiber [m]

    Kwlc=worm_diameters(i,2)*kBT/pL*dt^2/dm/dx; % scale kwlc to lb units %%%%%%%%%%%%%%%%% Need to modify for new pL
    KrpW=Kwlc*(0.25/(1-x0)^2-0.25+x0)*(L^2); % for wlc model
    bd_types = [bd_types;i,Kwlc,L,x0,KrpW];

    Bend_Stiff = [Bend_Stiff;pL*kBT/epsilon/dx];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Create Topology Intput File
% write output
name='in.worm_net'
fid = fopen(name,'w+');
fprintf(fid,'lammps cell input\n');
nAt=size(p,1);
fprintf(fid,'%d atoms\n', nAt);
nB=size(bd_lst,1);
fprintf(fid,'%d bonds\n', nB);
nAn=size(ang_lst,1);
fprintf(fid,'%d angles\n', nAn);

nat=2;
fprintf(fid,'%d atom types\n', nat);
nbt=num_worm;                 %for now, 1 (will need to change)
fprintf(fid,'%d bond types\n', nbt);
nangt=num_worm;
fprintf(fid,'%d angle types\n', nangt);%for now, 1 (will need to change)

fprintf(fid,'%g %g xlo xhi\n',xlo,max(p(:,2))+2*init_wall_dist);
fprintf(fid,'%g %g ylo yhi\n',ylo,max(p(:,3))+2*init_wall_dist);
fprintf(fid,'%g %g zlo zhi\n\n',zlo,max(p(:,4))+2*init_wall_dist);

fprintf(fid,'Masses\n\n');

m=rho*4/3*pi*(dx*mean(worm_diameters(2)/2))^3/dm;
for i=1:2
    fprintf(fid,'%d %g\n',i,m);
end
fprintf(fid,'\n');

fprintf(fid,'Bond Coeffs\n\n');
for i=1:num_worm
    fprintf(fid,'%d %g %g %g %g\n ',bd_types(i,1),bd_types(i,2),bd_types(i,3),bd_types(i,4),bd_types(i,5));
end
fprintf(fid,'\n');

fprintf(fid,'Angle Coeffs\n\n');%Cosine
for i=1:nangt
    %fprintf(fid,'%d %g %d %d\n',i,K,d,n);
    fprintf(fid,'%d %g\n',i,Bend_Stiff(i)); % High stiffness
end
fprintf(fid,'\n');


fprintf(fid,'Atoms\n\n');
% molecular type: aID, mID, aTy, x, y, z
mID = 1;
max_mol_node = worm_nodes(mID);
node_num = 1;
mol_IDs = [];
for i=1:nAt
    if node_num <= max_mol_node
        if p(i,5) == 1
            fprintf(fid,'%d %d %d %g %g %g\n',p(i,1),mID,1,p(i,2)+sim_shift(1),p(i,3)+sim_shift(2),p(i,4)+sim_shift(3));
            mol_IDs = [mol_IDs;mID];
        end
        if p(i,5) == 2
            fprintf(fid,'%d %d %d %g %g %g\n',p(i,1),mID,2,p(i,2)+sim_shift(1),p(i,3)+sim_shift(2),p(i,4)+sim_shift(3));
            mol_IDs = [mol_IDs;mID];
        end
    end
    if node_num > max_mol_node
        node_num = 1;
        mID = mID+1;
        max_mol_node = worm_nodes(mID);
        if p(i,5) == 1
            fprintf(fid,'%d %d %d %g %g %g\n',p(i,1),mID,1,p(i,2)+sim_shift(1),p(i,3)+sim_shift(2),p(i,4)+sim_shift(3));
            mol_IDs = [mol_IDs;mID];
        end
        if p(i,5) == 2
            fprintf(fid,'%d %d %d %g %g %g\n',p(i,1),mID,2,p(i,2)+sim_shift(1),p(i,3)+sim_shift(2),p(i,4)+sim_shift(3));
            mol_IDs = [mol_IDs;mID];
        end
    end
    node_num = node_num+1;
end
fprintf(fid,'\n');

fprintf(fid,'Bonds\n\n');
% WLC bID, bType, Atom1, Atom2
bd_number = 1;
for i=1:num_worm
    for j = 1:(worm_lengths(i)/(ds/dx))-1
        fprintf(fid,'%d %d %d %d\n',bd_lst(bd_number,1),i,bd_lst(bd_number,2),bd_lst(bd_number,3)); %This needs to change with bd type
        bd_number = bd_number+1;
    end
end
fprintf(fid,'\n');

fprintf(fid,'Angles\n\n');
% angleID, aType, atom1,2,3
ang_number = 1;
for i=1:num_worm
    for j = 1:(worm_lengths(i)/(ds/dx))-2
        fprintf(fid,'%d %d %d %d %d\n',ang_lst(ang_number,1),i,ang_lst(ang_number,2),ang_lst(ang_number,3),ang_lst(ang_number,4)); %Angle type needs to change
        ang_number = ang_number+ 1;
    end
end
fprintf(fid,'\n');
fclose(fid);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Create Simulation Input File
name='in.lmp4fiber'
fid = fopen(name,'w+');
fprintf(fid,'# lammps simulation for Fiber Network\n');
fprintf(fid,'units           lj\n');
fprintf(fid,'atom_style      molecular\n');
fprintf(fid,'atom_modify     first Branch\n');
fprintf(fid,'dimension       3\n');
fprintf(fid,'boundary        f f f\n');
fprintf(fid,'lattice         sc 5.0\n');
fprintf(fid,'region          box block 0 200 0 200 0 200 units lattice\n');
fprintf(fid,'\n');

fprintf(fid,'bond_style      wlc/pow\n');           %Set Bond and angle types
fprintf(fid,'angle_style     cosine\n');
fprintf(fid,'\n');
fprintf(fid,'read_data       in.worm_net\n');       %read the Topology file
fprintf(fid,'\n');

% Generate The Groups of atoms
Group_List = cell(num_worm,1);
Branches   = [];
nonBranches = [];
for i = 1:length(p(:,1))
    mol_ID = mol_IDs(i);
    Group_List(mol_ID) = {[cell2mat(Group_List(mol_ID));p(i,1)]};
end   

%Print the groups in the sim input file
fprintf(fid,'group   nonBranch type 1\n');
fprintf(fid,'group   Branch type 2\n');

%for i = 1: length(Group_List)
%    group_nodes = cell2mat(Group_List(i));
%    group_name = ['Fiber',num2str(i)];
%    fprintf(fid,['group ',group_name,' id ',num2str(group_nodes'),'\n']);
%end    
fprintf(fid,'\n');

fprintf(fid,'neighbor        0.5 bin\n');      %Set Neighbor values
fprintf(fid,'neigh_modify    delay 0 every 1 check yes\n');
fprintf(fid,'#neigh_modify exclude group  nonBranch nonBranch\n');
fprintf(fid,'#neigh_modify exclude group  nonBranch Branch\n');
fprintf(fid,'comm_modify cutoff 20\n');
fprintf(fid,'\n');

fprintf(fid,'pair_style lj/cut 10\n');      %Set Pairwise interactions
fprintf(fid,'pair_coeff 1 1 1e-15 1.5 1.5\n');
fprintf(fid,'pair_coeff 1 2 1e-15 1.5 1.5\n');   %When finished, This should be different for each fiber
fprintf(fid,'pair_coeff 2 2 1e-4 1.5\n');
fprintf(fid,'\n');

fprintf(fid,'timestep        0.02\n');      % Set Timestep
fprintf(fid,'fix             1 all nve\n');      % Set Fix conditions
%fprintf(fid,'fix             2 all viscous 0.01\n');
fprintf(fid,'\n');
fprintf(fid,'#Possible options for movement\n');
fprintf(fid,'fix             3 all wall/reflect xlo EDGE xhi EDGE\n');
fprintf(fid,'fix             4 all wall/reflect ylo EDGE yhi EDGE\n');
fprintf(fid,'fix             5 all wall/reflect zlo EDGE zhi EDGE\n');  % possible Wall options and movement
fprintf(fid,'\n');

fprintf(fid,['velocity      all     create     ', num2str(T),'     2424\n']);

%fprintf(fid,'variable ramp equal vdisplace(0,0.03)\n');
%fprintf(fid,'fix            6 all wall/lj126 xlo v_ramp 1.0 2.5 2.4\n');
%fprintf(fid,'variable ramp equal vdisplace(0,0.03)\n');
%fprintf(fid,'fix            7 all wall/lj126 ylo v_ramp 1.0 2.5 2.4\n');
%fprintf(fid,'variable ramp equal vdisplace(0,0.03)\n');
%fprintf(fid,'fix            8 all wall/lj126 zlo v_ramp 1.0 2.5 2.4\n');
%fprintf(fid,'\n');

%fprintf(fid,'#variable wiggle equal cwiggle(100,200.0,1000)\n');
%fprintf(fid,'#fix            6 all wall/lj126 xlo v_wiggle .1 2.0 1.5\n');
%fprintf(fid,'#variable wiggle equal cwiggle(0,250.0,1000)\n');
%fprintf(fid,'#fix            7 all wall/lj126 ylo v_wiggle .1 2.0 1.5\n');
%fprintf(fid,'#fix            8 all wall/lj126 ylo v_wiggle 1.0 1.0 2.5\n');
%fprintf(fid,'\n');
%fprintf(fid,'#Force addition to groups\n');
%fprintf(fid,'#fix             9 nonBranch addforce 0  0   0.0015546269651157256\n');
%fprintf(fid,'#fix             10 nonBranch addforce 0 0.0015546269651157256   0\n');
%fprintf(fid,'\n');

fprintf(fid,'#Generate Dump Files For Sim\n');          %Allow for the output file generation 
fprintf(fid,'dump           1 all xyz 10000 dump.network.xyz\n');
fprintf(fid,'dump           2 all custom 10000 dump.network.force id fx fy fz\n');
fprintf(fid,'dump           3 all custom 10000 dump.network.vel id vx vy vz\n');
fprintf(fid,'\n');

fprintf(fid,'run    4000000\n');
fprintf(fid,'dump           4 all xyz 1 dump.final_network.xyz\n');
fprintf(fid,'run    1\n');

fclose(fid);


