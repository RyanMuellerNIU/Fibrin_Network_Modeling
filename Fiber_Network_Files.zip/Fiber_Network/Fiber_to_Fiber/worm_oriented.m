% linear chain
function [p,t,bd_lst,ang_lst]=worm_oriented(N,ds,orient_Vec)
p=zeros(N,4);
bd_lst=zeros(N-1,3);%bond_list
ang_lst=zeros(N-2,4);%angle_list
for i=1:N-1
  bd_lst(i,1)=i;
  bd_lst(i,2)=i;
  bd_lst(i,3)=i+1;
end
for i=1:N-2
  ang_lst(i,1)=i;
  ang_lst(i,2)=i;
  ang_lst(i,3)=i+1;
  ang_lst(i,4)=i+2;
end

%set worm location
dz = ds*cosd(orient_Vec(6));
dy = ds*cosd(90-orient_Vec(6))*cosd(orient_Vec(5));
dx = ds*cosd(90-orient_Vec(6))*cosd(90-orient_Vec(5));

for i = 1:N
    p(i,1)=i;
    p(i,2)=orient_Vec(1)+(i-1)*dx-((ds*N-1)/2)*cosd(90-orient_Vec(6))*cosd(90-orient_Vec(5));
    p(i,3)=orient_Vec(2)+(i-1)*dy-((ds*N-1)/2)*cosd(orient_Vec(5));
    p(i,4)=orient_Vec(3)+(i-1)*dz-((ds*N-1)/2)*cosd(orient_Vec(6));
end

t=[];
end
