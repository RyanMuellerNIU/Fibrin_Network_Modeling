clc
clf
clear all;
%% Functions Used

% "fiber_parameter_generator"
% "worm_network_self_assem"
% -- Within worm_network_self_assem --> "worm_oriented"

%% Uses for output

% Unconnected Fiber network topology for Lammps simulations
% Lammps simulation Input File
% The "Fiber_Network_Reader" Uses the topology file to create the fully
% connected network
% Stores parameters for use in the network reader

%% Set Calculation Parameters
%----- normalized value ---------------------%
dx = .25e-6;                 % 0.5e-6;%1e-6; % m
tau=1;                       % 0.95;% best accuracy
vis=1e-3;                    % pa*s
rho=1e3;                     % kg/m^3
dt=(tau-0.5)/3*dx^2*rho/vis; % s
%-- palabos incompressible parameters--------%
u_phy = 5e-3;                % m/s
u_max = u_phy/(dx/dt);       % U_physical = 1
Re =  dx*u_phy/(vis/rho);
Nreso=1;                     % dx as 1, 
nu_lb = Nreso*u_max/Re;
dm = rho*dx*dx*dx;           % water mass
epsilon = dm*(dx/dt)^2;      % energy units
kBT=1.3806e-23*296;          % thermal energy
T = kBT/epsilon;             % Unitless Temperature

% General Simulation Parameters:
Time_Step = 0.03;
Runs_Per_Dump = 5000;
Runs = 2000000;


fprintf('Re %e\n',Re);
fprintf('Nreso %d\n',Nreso);
fprintf('u_Max %e\n',u_max);
fprintf('dx %e\n',dx);
fprintf('dt %e\n',dt);
fprintf('scaled temperature %e\n',T);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Set Network Parameters
% ---- Simulation Volume Dimensionless Units -----%

xlo = 0; xhi = 125;  % Volume of fiber network generation space
ylo = 0; yhi = 125;  % Unitless lengths 
zlo = 0; zhi = 125;  

init_wall_dist = 10; % minimum Unitless distance between walls and the atoms 

vol_factor = 1;      % This adjusts how spaced out the fibers are initially
                     % The larger the volume factor, the more spread out
                     % the fibers are. (If working with a dense nework it
                     % is suggested to spread the fibers out then bring
                     % them together during the simularion ie vol_fac>1.5)

L_Scale = 4;         % Scale from unit fiber (Unit fiber is 10 um)
                     % The unit fiber is based on the initial length used
                     % by the Houser paper 

l_0 = L_Scale*10e-6; % Mean Initial length of WLC [m]
ds = 1.5*dx;           % WLC Link Length Also refered to as the WLC bond length

Num_water = 4000;    % Number of water molecules generated in the sim space
Mass_water = dm/dm;  % Unitiless mass of the water molecules

num_rand = 7;       % Randomization Seed (Positive Int) 
                     % Controls the randomized distribution of fiber
                     % orientations, lengths, and diameters.
                     % the Lengths and fibers follow a normal distribution
                     % but still require the seed

% Create pL for the coarse-grained simulation
% These monomer values were taken from the Houser paper
pL_mon=1.5e-9;              % Mean persistence length (FOR MONOMER) [m] 0.4-2
L_mon = 45e-9;              % Length of monomer [m]
Show_graph = true;         % If you want to see the force vs length ratio

[A_Vals,l_m_Vals,k_p_Vals,kb] = fiber_parameter_generator(kBT,pL_mon,L_mon,ds,Show_graph); 
% The _Val arrays contain the parameters for unligated and ligated fiber
% parameters. Slot 1 is for unligated and slot 2 is for ligated. 
% kb is the bending coeficient for a monomer within the fiber.
% Units:
% A = Force Scaling Factor = Newton [N]
% l_m = Maximum Length = Meter [m]
% k_p = Repulsive Constant = [N*m^2]
% kb = Bending Energy = [J]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initialize WLC parameters Using experimental data

% Labels: li --> Ligated , unli --> Unligated

%Fiber density and other information
Branch_Point_Density = 1.2/((10^3)*(1e-6)^3)*(dx^3);    % per 10^3 um^3 CONVERTS to Brach_points/NU_vol
Branch_Point_IC = 0.7/((10^3)*(1e-6)^3)*(dx^3);         % Std Dev. +- Brach_points/NU_vol 
Fiber_Density = 4.2/((10^3)*(1e-6)^3)*(dx^3);           % Fibers per 10^3 um^3
Fiber_Density_IC = 0.2/((10^3)*(1e-6)^3)*(dx^3);        % Std Dev. +- Fibers per 10^3 um^3
Dist_Branch_Point = 23*(1e-6)/dx;                       % Distance between potential branches Converts um to NU length
Dist_Branch_Point_IC = 9*(1e-6)/dx;                     % Std Dev. Converts um to NU length
Fiber_D = [286*(1e-9)/dx , 48*(1e-9)/dx, 6.9*(1e-9)/dx];% Converts nm to NU Diameter [mean fiber diameter, diameter variance, monomer diameter]
                                                        % [Fiber Diameter, Std Dev, Monomer Diameter]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initialize the Network Structure Using the worm_network Function
sim_vol = [(xhi-xlo)*vol_factor,(yhi-ylo)*vol_factor,(zhi-zlo)*vol_factor]; % initializes the sim space with volume adjustments
num_worm = round(xhi*yhi*zhi*Fiber_Density);                                % Calculate the Number of worms for the simulation
L0_avg = l_0/dx;                                                            % Covert the mean fiber length to dimensionless units

% This function generates a worm network for use in self-assembly sims
[p,t,bd_lst,ang_lst,All_Orient,worm_lengths,worm_diameters,worm_nodes] = worm_network_self_assem(sim_vol,L0_avg, Fiber_D, num_worm, ds/dx, Dist_Branch_Point, num_rand);
% p = Array containing information on fiber atom ID, type, and position [ID,x,y,z,type] 
% t = array for triangles. this is not used
% bd_lst = array contain information on bonds between atoms. [bond ID, from node, to node]
% ang_lst = array containing information on angles between trios of atoms [Angle ID, node 1, node 1, node 3]]
% All_Orient = A Cell containing the orientation data for each fiber. within each cell: [x,y,z,x_ang,y_ang,z_ang]
% worm_lengths = An array containing all fiber lengths (Unitless lengths)
% worm_diameters = an array containing the diameter information for each fiber [Unitless_Diameter, Number of Monomers in parallel]
% worm_nodes = An array contain the number of nodes for each fiber WLC

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Create Bond and Angle Types
A = A_Vals(1);          %For unligated fibers use 1 and for ligated fibers, use 2
l_m = l_m_Vals(1);
k_p = k_p_Vals(1);

x0 = l_0/(L_Scale*l_m); % This is the equilibrium length ratio for the fiber (Force = Zero)

save("Force_Parameter_Vals.mat","A","l_m","k_p","kb","x0")

bd_types = [];          % Set the storage containers for bond types and bending stiffness
Bend_Stiff = [];
for i = 1:num_worm      %Loop for each worm
    L = ds/dx;                         % Length between each WLC node
    L_tot = worm_nodes(i)*ds;          % total length of the fiber [m]

    pL = kb*L_tot/kBT;                 % pL of the entire fiber [m]
    Bending_Energy = pL*kBT/epsilon/dx; % Dividing by epsilon converts the energy to unitless dimensions

    Kwlc=worm_diameters(i,2)*kBT/pL*dt^2/dm/dx; % Force Scaling factor (N*(kBT/pL))*dt^2/dm/dx = Dimensionless 
    KrpW=Kwlc*(0.25/(1-x0)^2-0.25+x0)*(L^2);    % The potential for each WLC Bond
    
    bd_types = [bd_types;i,Kwlc,L,x0,KrpW];     % Store the information in the bond list and bending energies
    Bend_Stiff = [Bend_Stiff;Bending_Energy];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Create Random water particals
init_len = length(p(:,1));
for i = 1:Num_water         %Loop for each water molecule
    p = [p;[init_len+i,rand()*max(p(:,2)),rand()*max(p(:,3)),rand()*max(p(:,4)),3]]; % Generate a random location within the sim area
end    


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create Topology Intput File
% write output

name='in.worm_net'                      % Name of the topology file
fid = fopen(name,'w+');                 % opens the new topology file
fprintf(fid,'lammps cell input\n');     % write the expected topology elements to the top of the file
nAt=size(p,1);
fprintf(fid,'%d atoms\n', nAt);
nB=size(bd_lst,1);
fprintf(fid,'%d bonds\n', nB);
nAn=size(ang_lst,1);
fprintf(fid,'%d angles\n', nAn);
nat=3;
fprintf(fid,'%d atom types\n', nat);
nbt=num_worm;                 
fprintf(fid,'%d bond types\n', nbt);
nangt=num_worm;
fprintf(fid,'%d angle types\n', nangt);

fprintf(fid,'%g %g xlo xhi\n',xlo,max(p(:,2))+2*init_wall_dist);    % Set the bounds of the whole simulation volume 
fprintf(fid,'%g %g ylo yhi\n',ylo,max(p(:,3))+2*init_wall_dist);    % This includes the walls and all other spaces
fprintf(fid,'%g %g zlo zhi\n\n',zlo,max(p(:,4))+2*init_wall_dist);  % you can change this size if you wish to strech the clot

fprintf(fid,'Masses\n\n');                                          % Set the masses of the atom types within the simulation
m=rho*4/3*pi*(dx*mean(worm_diameters(2)/2))^3/dm;                   % it may be a good Idea to investigate if the differing masses
for i=1:2                                                           % of each diameter type impacts results
    fprintf(fid,'%d %g\n',i,m);
end
fprintf(fid,'%d %g\n',3,Mass_water);                                % Include the mass of water molecules
fprintf(fid,'\n');

fprintf(fid,'Bond Coeffs\n\n');                                     %Set the bond coefficients for each bond type
for i=1:num_worm                                                    % Each worm should have it's own bond type due to the differing diameters
    fprintf(fid,'%d %g %g %g %g\n ',bd_types(i,1),bd_types(i,2),bd_types(i,3),bd_types(i,4),bd_types(i,5));
end
fprintf(fid,'\n');

fprintf(fid,'Angle Coeffs\n\n');%Cosine
for i=1:nangt                               % Set the bending stiffness of each angle type using the cosine angle relation
    fprintf(fid,'%d %g\n',i,Bend_Stiff(i)); % This relation requires the bending energy for each angle type and nothing more
end
fprintf(fid,'\n');

fprintf(fid,'Atoms\n\n');                   % Print the atom information
% molecular type: aID, mID, aTy, x, y, z
sim_shift = [init_wall_dist,init_wall_dist,init_wall_dist];   % The minimum distance away from the walls
mID = 1;                                                      % Molecule ID for lammps 
max_mol_node = worm_nodes(mID);                               % This records the nuber of nodes for the current worm
node_num = 1;                                                 % This records the current node number within the worm
mol_IDs = [];
for i=1:nAt-Num_water    % loop through every atom that isn't water
    if node_num <= max_mol_node     %If the current node is less than or equal to the max number of nodes for the current worm
        if p(i,5) == 1      %If the node is not a branch
            fprintf(fid,'%d %d %d %g %g %g\n',p(i,1),mID,1,p(i,2)+sim_shift(1),p(i,3)+sim_shift(2),p(i,4)+sim_shift(3));
            mol_IDs = [mol_IDs;mID]; % Save the molecule IDs for a sanity check and for future use
        end
        if p(i,5) == 2      %If the node is a branch
            fprintf(fid,'%d %d %d %g %g %g\n',p(i,1),mID,2,p(i,2)+sim_shift(1),p(i,3)+sim_shift(2),p(i,4)+sim_shift(3));
            mol_IDs = [mol_IDs;mID];% Save the molecule IDs for a sanity check and for future use
        end
    end
    if node_num > max_mol_node            %If the current node is more than the max number of nodes for the current worm
        node_num = 1;                     % Reset the node number to 1
        mID = mID+1;                      % Increase the molecule number by 1
        max_mol_node = worm_nodes(mID);   % Set the max node number to the new molecule
        if p(i,5) == 1                    %If the node is not a branch
            fprintf(fid,'%d %d %d %g %g %g\n',p(i,1),mID,1,p(i,2)+sim_shift(1),p(i,3)+sim_shift(2),p(i,4)+sim_shift(3));
            mol_IDs = [mol_IDs;mID];
        end
        if p(i,5) == 2                    %If the node is a branch
            fprintf(fid,'%d %d %d %g %g %g\n',p(i,1),mID,2,p(i,2)+sim_shift(1),p(i,3)+sim_shift(2),p(i,4)+sim_shift(3));
            mol_IDs = [mol_IDs;mID];
        end
    end
    node_num = node_num+1;  % Increase the node number by 1
end

% Add water Particles
for i = nAt-(Num_water-1):nAt % loop for each water molecule
    fprintf(fid,'%d %d %d %g %g %g\n',p(i,1),mID+1,3,p(i,2)+sim_shift(1),p(i,3)+sim_shift(2),p(i,4)+sim_shift(3));
end    
fprintf(fid,'\n');

fprintf(fid,'Bonds\n\n');                   % print the bond types
% WLC bID, bType, Atom1, Atom2
bd_number = 1;                              % Set the bond number to 1
for i=1:num_worm                            % loop for each worm
    for j = 1:(worm_lengths(i)/(ds/dx))-1   % loop for each bond within the current worm
        fprintf(fid,'%d %d %d %d\n',bd_lst(bd_number,1),i,bd_lst(bd_number,2),bd_lst(bd_number,3)); 
        bd_number = bd_number+1;            % Increase the bond number by 1
    end
end
fprintf(fid,'\n');

fprintf(fid,'Angles\n\n');                  % print the angle types
% angleID, aType, atom1,2,3
ang_number = 1;
for i=1:num_worm %loop for each worm
    for j = 1:(worm_lengths(i)/(ds/dx))-2   % loopf for each angle within the worm
        fprintf(fid,'%d %d %d %d %d\n',ang_lst(ang_number,1),i,ang_lst(ang_number,2),ang_lst(ang_number,3),ang_lst(ang_number,4)); %Angle type needs to change
        ang_number = ang_number+ 1;         % Increase the angle number by 1
    end
end
fprintf(fid,'\n');
fclose(fid);    % close the topology file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Create Simulation Input File
name='in.lmp4fiber'     %Crease the new simulation input file
fid = fopen(name,'w+');
fprintf(fid,'# lammps simulation for Fiber Network\n');     % Title for ease of use
fprintf(fid,'units           lj\n');              
fprintf(fid,'atom_style      molecular\n');
fprintf(fid,'atom_modify     first Branch\n');              % Set the general parameters  for lammps simulations
fprintf(fid,'dimension       3\n');
fprintf(fid,'boundary        f f f\n');                     % Solid bariers are prefered at this time (no periodic)
fprintf(fid,'lattice         sc 5.0\n');
fprintf(fid,'region          box block 0 200 0 200 0 200 units lattice\n');
fprintf(fid,'\n');

fprintf(fid,'bond_style      wlc/pow\n');           %Set Bond and angle types
fprintf(fid,'angle_style     cosine\n');
fprintf(fid,'\n');
fprintf(fid,'read_data       in.worm_net\n');       %read the Topology file
fprintf(fid,'\n');

% Generate The Groups of atoms
Group_List = cell(num_worm,1); % If group IDs are required, use this
Branches   = [];
nonBranches = [];
%for i = 1:length(p(:,1))
%    mol_ID = mol_IDs(i);
%    Group_List(mol_ID) = {[cell2mat(Group_List(mol_ID));p(i,1)]};
%end   

%Print the groups in the sim input file
fprintf(fid,'group   nonBranch type 1\n');      % Set and print the group types
fprintf(fid,'group   Branch type 2\n');
fprintf(fid,'group   Water type 3\n');

%for i = 1: length(Group_List)                  % If the fiber groups are required, use this
%    group_nodes = cell2mat(Group_List(i));
%    group_name = ['Fiber',num2str(i)];
%    fprintf(fid,['group ',group_name,' id ',num2str(group_nodes'),'\n']);
%end    
fprintf(fid,'\n');

fprintf(fid,'neighbor        0.5 bin\n');      %Set Neighbor values
fprintf(fid,'neigh_modify    delay 0 every 1 check yes\n');
fprintf(fid,'#neigh_modify exclude group  nonBranch nonBranch\n'); % if you don't want them to interact, uncheck these
fprintf(fid,'#neigh_modify exclude group  nonBranch Branch\n');
fprintf(fid,'comm_modify cutoff 20\n');
fprintf(fid,'\n');

fprintf(fid,'pair_style lj/cut 10\n');           %Set Pairwise interactions
fprintf(fid,['pair_coeff 1 1 ', num2str(k_p),' ', num2str(ds*.75/dx),' ', num2str(ds*.75/dx),'\n']);
fprintf(fid,['pair_coeff 1 2 ', num2str(k_p),' ', num2str(ds*.75/dx),' ', num2str(ds*.75/dx),'\n']);   %If desired, these could be different for each fiber
fprintf(fid,'pair_coeff 2 2 1e-4 1.5\n');                                                        % it's more work but may make a difference
fprintf(fid,'pair_coeff 3 * 1e-15 3 3\n');
fprintf(fid,'\n');

fprintf(fid,['timestep        ',num2str(Time_Step),'\n']);                 % Set Timestep (Should be stable when in the hudreths space)
fprintf(fid,'fix             1 all nve\n');             % Set Fix conditions
%fprintf(fid,'fix             2 all viscous 0.01\n');   % Remove viscus term if working with temperature/ velocity sets
fprintf(fid,'\n');
fprintf(fid,'#Possible options for movement\n');
fprintf(fid,'fix             3 all wall/reflect xlo EDGE xhi EDGE\n');  % Place walls at the edges of the sim space
fprintf(fid,'fix             4 all wall/reflect ylo EDGE yhi EDGE\n');
fprintf(fid,'fix             5 all wall/reflect zlo EDGE zhi EDGE\n');  % possible Wall options and movement
fprintf(fid,'\n');

fprintf(fid,['velocity      all     create     ', num2str(T),'     1417\n']); %Set the temperature of the sim with random seed

% Options for moving the walls
%fprintf(fid,'variable ramp equal vdisplace(0,0.03)\n');
%fprintf(fid,'fix            6 all wall/lj126 xlo v_ramp 1.0 2.5 2.4\n');
%fprintf(fid,'variable ramp equal vdisplace(0,0.03)\n');
%fprintf(fid,'fix            7 all wall/lj126 ylo v_ramp 1.0 2.5 2.4\n');
%fprintf(fid,'variable ramp equal vdisplace(0,0.03)\n');
%fprintf(fid,'fix            8 all wall/lj126 zlo v_ramp 1.0 2.5 2.4\n');
%fprintf(fid,'\n');
%fprintf(fid,'#variable wiggle equal cwiggle(100,200.0,1000)\n');
%fprintf(fid,'#fix            6 all wall/lj126 xlo v_wiggle .1 2.0 1.5\n');
%fprintf(fid,'#variable wiggle equal cwiggle(0,250.0,1000)\n');
%fprintf(fid,'#fix            7 all wall/lj126 ylo v_wiggle .1 2.0 1.5\n');
%fprintf(fid,'#fix            8 all wall/lj126 ylo v_wiggle 1.0 1.0 2.5\n');
%fprintf(fid,'\n');

% Options for moving the atoms
%fprintf(fid,'#Force addition to groups\n');
%fprintf(fid,'#fix             9 nonBranch addforce 0  0   0.0015546269651157256\n');
%fprintf(fid,'#fix             10 nonBranch addforce 0 0.0015546269651157256   0\n');
%fprintf(fid,'\n');

fprintf(fid,'#Generate Dump Files For Sim\n');          %Allow for the output file generation 
fprintf(fid,['dump           1 all xyz ',num2str(Runs_Per_Dump),' dump.network.xyz\n']);
fprintf(fid,['dump           2 all custom ',num2str(Runs_Per_Dump),' dump.network.force id fx fy fz\n']);
fprintf(fid,['dump           3 all custom ',num2str(Runs_Per_Dump),' dump.network.vel id vx vy vz\n']);
fprintf(fid,'\n');

fprintf(fid,['run    ',num2str(Runs),'\n']);
fprintf(fid,'\n');
%fprintf(fid,['velocity      Water     create     ', num2str(T/10),'     1417\n']);
%fprintf(fid,'\n');
%fprintf(fid,'run    1000000\n');
%fprintf(fid,'\n');
fprintf(fid,'dump           4 all xyz 1 dump.final_network.xyz\n'); % THIS IS REQUIRED TO USE THE FILE READER
fprintf(fid,'\n');
fprintf(fid,'run    1\n');
fclose(fid);


