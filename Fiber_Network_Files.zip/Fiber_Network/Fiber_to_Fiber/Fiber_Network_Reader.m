clc
clf
clear all;

load("Force_Parameter_Vals.mat")

%% Set Calculation Parameters
%----- normalized value ---------------------%
dx = .25e-6;                 % 0.5e-6;%1e-6; % m
tau=1;                       % 0.95;% best accuracy
vis=1e-3;                    % pa*s
rho=1e3;                     % kg/m^3
dt=(tau-0.5)/3*dx^2*rho/vis; % s
%-- palabos incompressible parameters--------%
u_phy = 5e-3;                % m/s
u_max = u_phy/(dx/dt);       % U_physical = 1
Re =  dx*u_phy/(vis/rho);
Nreso=1;                     % dx as 1, 
nu_lb = Nreso*u_max/Re;
dm = rho*dx*dx*dx;           % water mass
epsilon = dm*(dx/dt)^2;      % energy units
kBT=1.3806e-23*296;          % thermal energy
T = kBT/epsilon;             % Unitless Temperature

% General Simulation Parameters:
Time_Step = 0.05;
Runs_Per_Dump = 5000;
Runs = 1500000;

Branch_Cutoff=7;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fid_dump = fopen("dump.final_network.xyz", 'r'); %Open the Dump File
Number_Atoms=fscanf(fid_dump, '%d', 1);          %Obtain Number of atoms
Skip_line = fscanf(fid_dump, '%s',3);            %Skip uneeded information

p = [];
for i = 1:Number_Atoms
    Atom_Pos = fscanf(fid_dump, '%d %f %f %f',4)'; % Collect the Position and type data from Dump
    p = [p;[i,Atom_Pos]];  % Add the Atom ID and store the information (This should Resemble the P matrix from Topology)
end
fclose(fid_dump);

fid_topology = fopen("in.worm_net", 'r'); %Open the Topology File
fscanf(fid_topology, '%s',3);             % Skips title
Number_Atoms_top = fscanf(fid_topology, '%d',1);% Scan for the number of atoms and make sure it matches the dump
fscanf(fid_topology, '%s',1);             %Skip lable
Number_Bonds = fscanf(fid_topology, '%d',1);    %scan for the numbner of bonds
fscanf(fid_topology, '%s',1);              %Skip lable
Number_Angles = fscanf(fid_topology, '%d',1);   %Scan for the number of angles
fscanf(fid_topology, '%s',1);             %Skip lable
Atom_types = fscanf(fid_topology, '%d',1);   %Scan for the number of atom types
fscanf(fid_topology, '%s',2);             %Skip lable
Bond_Types = fscanf(fid_topology, '%d',1);   %Scan for the number of bond types
fscanf(fid_topology, '%s',2);             %Skip lable
Angle_Types = fscanf(fid_topology, '%d',1);   %Scan for the number of angle types
fscanf(fid_topology, '%s',2);             %Skip lable
x_bounds = fscanf(fid_topology, '%f %f',2);
fscanf(fid_topology, '%s',2);             %Skip lable
y_bounds = fscanf(fid_topology, '%f %f',2);
fscanf(fid_topology, '%s',2);             %Skip lable
z_bounds = fscanf(fid_topology, '%f %f',2);
fscanf(fid_topology, '%s',2);             %Skip lable

Masses_found = false; % set the loop breaker to false
Masses = [];
while Masses_found == false
    info = fscanf(fid_topology, '%s',1); % Scan an element of the topology file
    Mass_Check = strcmp(info,'Masses');   % Check if the element is the string 'Bonds' (This is the lable in the topology file)
    if Mass_Check == true                % If the string is bonds, Start scanning the bond list 
        Masses_found = true;              % Set the loop breaker to true to end loop after scan
        for i = 1:Atom_types
            Mass_Info = fscanf(fid_dump, '%d %f',2)'; %Scan the bonds from the topology file
            Masses = [Masses;Mass_Info];                    %Create the bond list
        end    
    end
end

Bond_coef_found = false; % set the loop breaker to false
bd_Coefs = [];
while Bond_coef_found == false
    info = fscanf(fid_topology, '%s',1); % Scan an element of the topology file
    Bond_Check = strcmp(info,'Coeffs');   % Check if the element is the string 'Bonds' (This is the lable in the topology file)
    if Bond_Check == true                % If the string is bonds, Start scanning the bond list 
        Bond_coef_found = true;              % Set the loop breaker to true to end loop after scan
        for i = 1:Bond_Types
            Coef_Info = fscanf(fid_dump, '%d %f %f %f %f',5)'; %Scan the bonds from the topology file
            bd_Coefs = [bd_Coefs;Coef_Info];                    %Create the bond list
        end    
    end
end

Ang_coef_found = false; % set the loop breaker to false
Ang_Coefs = [];
while Ang_coef_found == false
    info = fscanf(fid_topology, '%s',1); % Scan an element of the topology file
    Coeff_Check = strcmp(info,'Coeffs');   % Check if the element is the string 'Bonds' (This is the lable in the topology file)
    if Coeff_Check == true                % If the string is bonds, Start scanning the bond list 
        Ang_coef_found = true;              % Set the loop breaker to true to end loop after scan
        for i = 1:Angle_Types
            Coef_Info = fscanf(fid_dump, '%d %f',2)'; %Scan the bonds from the topology file
            Ang_Coefs = [Ang_Coefs;Coef_Info];                    %Create the bond list
        end    
    end
end

Bonds_found = false; % set the loop breaker to false
bd_lst = [];
while Bonds_found == false
    info = fscanf(fid_topology, '%s',1); % Scan an element of the topology file
    Bond_Check = strcmp(info,'Bonds');   % Check if the element is the string 'Bonds' (This is the lable in the topology file)
    if Bond_Check == true                % If the string is bonds, Start scanning the bond list 
        Bonds_found = true;              % Set the loop breaker to true to end loop after scan
        for i = 1:Number_Bonds
            Bond_Info = fscanf(fid_dump, '%d %d %d %d',4)'; %Scan the bonds from the topology file
            bd_lst = [bd_lst;Bond_Info];                    %Create the bond list
        end    
    end
end

Num_worms = Bond_Types;   % Find the number of worms from the bond list (Uses bond types to signify number of worms)
figure(1)
view(1,1)
hold on
Branch_Nodes = [];              %Set data containers for filling
All_Branch_Neighbors = {};
branch_count = 1;
All_Worm_Nodes = {};
for i = 1:Num_worms            %Loop through each worm
    worm_bonds = [];           %Set the short term storage
    worm_nodes = [];
    worm_branches = [];
    worm_branch_neighbors = [];
    for j = 1:Number_Bonds     %Loop through each bond in all worms
        cur_bond = bd_lst(j,:); % Set the current bond relationship
        if cur_bond(2) == i     % Find all the bonds that make up the curent worm
           worm_bonds = [worm_bonds;cur_bond]; %Store all the bonds for the current worm
        end
    end
    for j = 1:length(worm_bonds(:,1))   %Loop through each bond in the CURRENT WORM
        from_node = worm_bonds(j,3);    % set the from and to nodes for the current bond (Gives atom IDs)
        to_node = worm_bonds(j,4);
        
        if j <length(worm_bonds(:,1))   % If the bond isn't the last bond in the worm
            worm_nodes = [worm_nodes;[from_node,p(from_node,3),p(from_node,4),p(from_node,5)]]; % get the position of the from node and store it
            if p(from_node,2) == 2                         %Check if the "from node" is a branch (The value will be 2 if a node is a branch) 
                worm_branches = [worm_branches;from_node]; %Store the branch ID
                if j == 1                                  %If this is the first Node of the worm
                    Branch_Neighbors = to_node;            %The "to node" must be a neighbor
                else                                          %If this node is not the first or the last node
                    Branch_Neighbors = [from_node-1,to_node]; %The "from node -1" and the "to node" are neighbors  
                end
                worm_branch_neighbors = [worm_branch_neighbors,Branch_Neighbors]; %Store the branch neighbors per worm
                All_Branch_Neighbors(branch_count) = {Branch_Neighbors}; %Store the branch neighbors in a cell for future use
                branch_count = branch_count+1; %Increase the branch count
            end    
        
        else                            % If the bond is the last bond in the worm
            worm_nodes = [worm_nodes;[from_node,p(from_node,3),p(from_node,4),p(from_node,5)]]; % save the position of the from node
            if p(from_node,2) == 2                                          % Check if the from node is a branch
                worm_branches = [worm_branches;from_node];                  % Save the branch node
                Branch_Neighbors = [from_node-1,to_node];                   %The "from node -1" and the "to node" are neighbors 
                worm_branch_neighbors = [worm_branch_neighbors,Branch_Neighbors];%Store the branch neighbors per worm
                All_Branch_Neighbors(branch_count) = {Branch_Neighbors};    %Store the branch neighbors in a cell for future use
                branch_count = branch_count+1;                              %Increase the branch count
            end 
            worm_nodes = [worm_nodes;[to_node,p(to_node,3),p(to_node,4),p(to_node,5)]]; % save the position of the to node
            if p(to_node,2) == 2                                            % Check if the from node is a branch
                worm_branches = [worm_branches;to_node];                    % Save the branch node
                Branch_Neighbors = from_node;                               %The "From node" is the only neighbor
                worm_branch_neighbors = [worm_branch_neighbors,Branch_Neighbors];%Store the branch neighbors per worm
                All_Branch_Neighbors(branch_count) = {Branch_Neighbors};    %Store the branch neighbors in a cell for future use
                branch_count = branch_count+1;                              %Increase the branch count
            end 
        end

    end
    Branch_Nodes = [Branch_Nodes;worm_branches];        %Store the branch nodes in a single array
    
    All_Worm_Nodes(i) = {worm_nodes};

    plot3(worm_nodes(:,2),worm_nodes(:,3),worm_nodes(:,4),'b')  %Plot the worm using the node positions
    for j = 1: length(worm_branches(:,1))                       %Plot the Branches FOR A SINGLE WORM
        plot3(p(worm_branches(j),3),p(worm_branches(j),4),p(worm_branches(j),5),'rx') %Branches are red x's
    end
    for j = 1:length(worm_branch_neighbors)                     %Plot the Branch Neighbors FOR A SINGLE WORM
        plot3(p(worm_branch_neighbors(j),3),p(worm_branch_neighbors(j),4),p(worm_branch_neighbors(j),5),'go') %Branch Neighbors are green o's
    end    
    %pause(0.00001)
end    

% Construct the branches Between Branch nodes that are close enough
% Three Types of Branches: End-to-End, True Branch, Pierced Branch

Branch_Clusters = {};
Count = 1;
for i = 1:length(Branch_Nodes) % Loop for each Branch node in the simulation
    Bound_Branches = [];                                        % Reset the temp storage
    Cur_Branch = Branch_Nodes(i,1);                             % Select the current branch
    Cur_Branch_pos = p(Cur_Branch,3:5);                         % Obtain the position of the branch [lb units]
    Cur_Branch_Neighbors = cell2mat(All_Branch_Neighbors(i));   % Obtain the neighbors for the current branch xxxxxxx
    for j = 1:length(Branch_Nodes)                              % Loop for all branch nodes
        if j~=i                                                 % Loop through all other branch nodes    
            Check_Branch = Branch_Nodes(j,1);                   % Select the branch being checked for proximity
            Check_Branch_pos = p(Check_Branch,3:5);             % Obtain the position of the branch being checked
            Check_Branch_Neighbors = cell2mat(All_Branch_Neighbors(j));% Obtain the neighbors for the check branch
            % Calculate the distance between the current branch and the branch being checked.
            Dist = sqrt((Check_Branch_pos(1)-Cur_Branch_pos(1))^2+(Check_Branch_pos(2)-Cur_Branch_pos(2))^2+(Check_Branch_pos(3)-Cur_Branch_pos(3))^2);
            if Dist < Branch_Cutoff && Cur_Branch < Check_Branch % If the distance is within the cutoff region and is the first occurance of the relationship, save it.
                Bound_Branches = [Bound_Branches;Check_Branch];
            end    
        end    
    end
    if isempty(Bound_Branches) == false % This will only create clusters when branches are close enough (avoids void elements)
        Branch_Clusters(Count) = {[Cur_Branch;Bound_Branches]};   %Stores all Bound Branches
        Count = Count+1; % sets the index for saving the branches in the cluster cell
    end
end    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Shift the Atom IDs to account for the introduction of clusters

% Stage 1: Flag the branches within clusters that need to be reduced into a single cluster node.

p_NoCluster = p;                                                    % Set the initial Atom list
All_Worm_Nodes_no_cluster = {};                                     % Initialize a new cell for worm by worm loop writing
for i = 1:Num_worms                          % Loop for each worm like chain
    worm_nodes = cell2mat(All_Worm_Nodes(i));                       % Obtain the number of nodes for the current worm
    for j = 1:length(worm_nodes(:,1))        % Loop for each node in the current worm
        cur_node = worm_nodes(j,1);                                 % Select the current node 
        for k = 1:length(Branch_Clusters)    % Loop for each cluster in the fiber network
            Cur_Cluster = cell2mat(Branch_Clusters(k));             % Select the current cluster of branch nodes
            for l = 1:length(Cur_Cluster)    % Loop for each branch node in the cluster
                Branch_Node = Cur_Cluster(l);                       % Select the current branch node
                if cur_node == Branch_Node   % If the current node is the selected branch node
                        worm_nodes(j,:) = [-k,0,0,0];   % flag the current node for removal/replacement for the cell stoarage
                        p_NoCluster(Branch_Node,:) = [-k,0,0,0,0]; % flag the current node for removal in the list storage
                end
            end    
        end    
    end
    All_Worm_Nodes_no_cluster(i) = {worm_nodes};    % Store the Worm nodes with flags for future use.
end    

% Stage 2: Read the flags within the lists to remove branches within clusters and create a new atom list with adjusted atom IDs
% This stage also removes the water atoms added in the self assembly

p_NoCluster_Adjusted = [];          % Set the new list for atom ID storage
new_node_ID = 1;                    % Set the new atom ID value
for i = 1:length(p(:,1))            % For all atoms in the ORIGINAL atom list
    node_ID = p_NoCluster(i,1);     % Select the current node ID
    atom_type = p_NoCluster(i,2);   % Determine the atom type for the selected Atom
    if node_ID > 0 && atom_type <3  % If the atom is NOT flaged for removal NOR a water element, save the atom.
       p_NoCluster_Adjusted = [p_NoCluster_Adjusted;[new_node_ID,p(i,2:5)]]; % Save the atom with a new ID for use in next simulation
       new_node_ID = new_node_ID +1; % Increase the Atom ID
    end    
end    

% Stage 3: Reduce the branches within the cluster to one node and add the new cluster node to the atom ID lists

All_Cluster_Locations = [];                         % List to save all the new cluster node locations
p_Cluster = p_NoCluster_Adjusted;                   % New list to save the Atom List with cluster nodes included
for i = 1:length(Branch_Clusters)  % Loop for each cluster in the fiber network
    Cur_Cluster = cell2mat(Branch_Clusters(i));     % Select the current cluster (This cell stores the branch IDs inclused in the cluster)
    Cur_nodes = [];                                 % Reset the current nodes array
    for j = 1: length(Cur_Cluster)                  % Loop for each branch node within the current cluster
        Node_num = Cur_Cluster(j);                  % Deternine the atom ID of the current branch node
        Node_pos = p(Node_num,3:5);                 % Obtain the position of the current branch node from the ORIGINAL atom list
        Cur_nodes = [Cur_nodes;[Node_num,Node_pos]]; % Save the branch node's information within the cur nodes array
    end
    % Calculate the AVERAGE position of all branch nodes included in the current cluster. This position will serve as the location for the cluster.
    Cluster_Location = (1/length(Cur_nodes(:,1)))*[sum(Cur_nodes(:,2)),sum(Cur_nodes(:,3)),sum(Cur_nodes(:,4))]; 
    All_Cluster_Locations = [All_Cluster_Locations;Cluster_Location];           % Save the cluster node location for future use
    p_Cluster = [p_Cluster;[length(p_NoCluster_Adjusted)+i,1,Cluster_Location]]; % Add the new cluster node to the end of the Atom ID List
end   

% Stage 4: Insert the cluster nodes into the existing WLCs where the flags indicate where each cluster node should be placed.

All_Worm_Nodes_cluster = {};                                % Create a new cell array for storing WLC nodes including the cluster nodes
node_ID = 1;                                                % Reset the node ID count once more
for i = 1:Num_worms                   % Loop for each WLC in the fiber network
    worm_nodes = cell2mat(All_Worm_Nodes_no_cluster(i));    % Use the Worm node list with flaged branch nodes to insert the new cluster nodes     
    for j = 1:length(worm_nodes(:,1)) % Loop for each node in the Current WLC
        cur_node = worm_nodes(j,1);                         % Select the current node ID
        if cur_node > 0               % If the current node is NOT flagged
            worm_nodes(j,:) = [node_ID,worm_nodes(j,2:4)];  % Save the Atom in the list with it's new Atom ID 
            node_ID = node_ID+1;                            % Increase the Atom ID
        end
        if cur_node < 0               % If the current nod IS flagged
            cluster_ID = abs(cur_node);                     % Obtain the Cluster ID from the flag value (- index_val)
            % Insert the cluster node into the WLC using the New Cluster ID and Cluster location.
            worm_nodes(j,:) = [p_Cluster(length(p_NoCluster_Adjusted(:,1))+cluster_ID,1),p_Cluster(length(p_NoCluster_Adjusted(:,1))+cluster_ID,3:5)];
        end    
    end
    All_Worm_Nodes_cluster(i) = {worm_nodes};               % Store the WLC nodes which now include the cluster nodes 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Create new bond list and angle list:

bd_num = 1;
bd_lst_cluster = [];
ang_num = 1;
ang_lst_cluster =[];
figure(2)
view(1,1)
hold on
for i = 1: Num_worms
    worm_nodes = cell2mat(All_Worm_Nodes_cluster(i));
    for j = 1 : length(worm_nodes)-1
        from_node = worm_nodes(j,:);
        to_node = worm_nodes(j+1,:);
        bd_lst_cluster = [bd_lst_cluster;[bd_num,i,from_node(1),to_node(1)]];
        bd_num = bd_num+1;
    end
    for j = 1 : length(worm_nodes)-2
        ang_lst_cluster = [ang_lst_cluster;[ang_num,i,worm_nodes(j,1),worm_nodes(j+1,1),worm_nodes(j+2,1)]];
        ang_num = ang_num +1;
    end    
    plot3(worm_nodes(:,2),worm_nodes(:,3),worm_nodes(:,4),'b-')
end    
plot3(All_Cluster_Locations(:,1),All_Cluster_Locations(:,2),All_Cluster_Locations(:,3),'rx')

All_cluster_neighbors = {};
for i = 1:length(Branch_Clusters)
    Cluster_Branches = cell2mat(Branch_Clusters(i));
    cluster_neighbors = {};
    for j = 1: length(Cluster_Branches)
        Cur_Branch = Cluster_Branches(j);
        for k = 1:length(Branch_Nodes)
            Check_Branch = Branch_Nodes(k);
            if Check_Branch == Cur_Branch
                Branch_neighbors = All_Branch_Neighbors(k)';
                cluster_neighbors(j) = Branch_neighbors;
            end    
        end
    end    
    All_cluster_neighbors(i) = {cluster_neighbors};
end

num_new_bonds = 1;
bd_lst_cluster_bonds = bd_lst_cluster;
New_Bond_Lengths = [];
for i = 1:length(All_cluster_neighbors)
    Cluster_Neighbors = All_cluster_neighbors(i);
    Cluster_Node_ID = length(p_NoCluster_Adjusted(:,1))+i;
    for j = 1:length(Cluster_Neighbors{1}{1})
        from_node = Cluster_Neighbors{1}{1}(j);
        from_node_pos = p(from_node,3:5);
        [from_node_adjusted,col] = find(p_Cluster(:,3:5)==from_node_pos);%trasnlate into the new atom list
        from_node_adjusted = mode(from_node_adjusted(:,1));
        for k = 1:length(Cluster_Neighbors{1}{2})
            to_node = Cluster_Neighbors{1}{2}(k);
            to_node_pos = p(to_node,3:5);
            [to_node_adjusted,col] = find(p_Cluster(:,3:5)==to_node_pos);%trasnlate into the new atom list
            to_node_adjusted =mode(to_node_adjusted(:,1));
            Bond_length = sqrt((to_node_pos(1)-from_node_pos(1))^2+(to_node_pos(2)-from_node_pos(2))^2+(to_node_pos(3)-from_node_pos(3))^2);
            New_Bond_Lengths = [New_Bond_Lengths;Bond_length];
            bd_lst_cluster_bonds = [bd_lst_cluster_bonds;[length(bd_lst_cluster(:,1)),Bond_Types+num_new_bonds,from_node_adjusted,to_node_adjusted]];
            %plot3([p(from_node,3),p(to_node,3)],[p(from_node,4),p(to_node,4)],[p(from_node,5),p(to_node,5)],'m-o')
            plot3([p_Cluster(from_node_adjusted,3),p_Cluster(to_node_adjusted,3)],[p_Cluster(from_node_adjusted,4),p_Cluster(to_node_adjusted,4)],[p_Cluster(from_node_adjusted,5),p_Cluster(to_node_adjusted,5)],'m-o')
            num_new_bonds = num_new_bonds + 1;
        end    
    end    
end

% Create new bond types for the fiber-fiber bonds

for i = 1:num_new_bonds-1      %Loop for each new bond
    L = New_Bond_Lengths(i);                         % Length between each WLC node
    pL = kb*(L*dx)/kBT;                 % pL of the entire fiber [m]

    Kwlc=1000*kBT/pL*dt^2/dm/dx; % Force Scaling factor (N*(kBT/pL))*dt^2/dm/dx = Dimensionless 
    KrpW=Kwlc*(0.25/(1-x0)^2-0.25+x0)*(L^2);    % The potential for each WLC Bond
    
    bd_Coefs = [bd_Coefs;Bond_Types+i,Kwlc,L,x0,KrpW];     % Store the information in the bond list and bending energies
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create Topology Intput File
% write output

name='in.worm_net_connected'                      % Name of the topology file
fid = fopen(name,'w+');                 % opens the new topology file
fprintf(fid,'lammps cell input\n');     % write the expected topology elements to the top of the file
nAt=size(p_Cluster,1);
fprintf(fid,'%d atoms\n', nAt);
nB=size(bd_lst_cluster_bonds,1);
fprintf(fid,'%d bonds\n', nB);
nAn=size(ang_lst_cluster,1);
fprintf(fid,'%d angles\n', nAn);
nat=2;
fprintf(fid,'%d atom types\n', nat);
nbt=length(bd_Coefs(:,1));                 
fprintf(fid,'%d bond types\n', nbt);
nangt=length(Ang_Coefs(:,1));
fprintf(fid,'%d angle types\n', nangt);

fprintf(fid,'%g %g xlo xhi\n',x_bounds(1),x_bounds(2));    % Set the bounds of the whole simulation volume 
fprintf(fid,'%g %g ylo yhi\n',y_bounds(1),y_bounds(2));    % This includes the walls and all other spaces
fprintf(fid,'%g %g zlo zhi\n\n',z_bounds(1),z_bounds(2));  % you can change this size if you wish to strech the clot

fprintf(fid,'Masses\n\n');                                          % Set the masses of the atom types within the simulation
                                                                    % it may be a good Idea to investigate if the differing masses
for i=1:nat                                                           % of each diameter type impacts results
    fprintf(fid,'%d %g\n',i,Masses(i,2));
end
fprintf(fid,'\n');

fprintf(fid,'Bond Coeffs\n\n');                                     %Set the bond coefficients for each bond type
for i=1:length(bd_Coefs(:,1))                                       % Each worm should have it's own bond type due to the differing diameters
    fprintf(fid,'%d %g %g %g %g\n ',bd_Coefs(i,1),bd_Coefs(i,2),bd_Coefs(i,3),bd_Coefs(i,4),bd_Coefs(i,5));
end
fprintf(fid,'\n');

fprintf(fid,'Angle Coeffs\n\n');%Cosine
for i=1:nangt                               % Set the bending stiffness of each angle type using the cosine angle relation
    fprintf(fid,'%d %g\n',i,Ang_Coefs(i,2)); % This relation requires the bending energy for each angle type and nothing more
end
fprintf(fid,'\n');

fprintf(fid,'Atoms\n\n');                   % Print the atom information
% molecular type: aID, mID, aTy, x, y, z
mID = 1;                                                      % Molecule ID for lammps 
max_mol_node = length(cell2mat(All_Worm_Nodes_cluster(mID))); % This records the nuber of nodes for the current worm
node_num = 1;                                                 % This records the current node number within the worm
mol_IDs = [];
for i=1:nAt     % loop through every atom that isn't water
    if node_num <= max_mol_node     %If the current node is less than or equal to the max number of nodes for the current worm
        fprintf(fid,'%d %d %d %g %g %g\n',p_Cluster(i,1),mID,p_Cluster(i,2),p_Cluster(i,3),p_Cluster(i,4),p_Cluster(i,5));
        mol_IDs = [mol_IDs;mID]; % Save the molecule IDs for a sanity check and for future use
    end
    if node_num > max_mol_node            %If the current node is more than the max number of nodes for the current worm
        node_num = 1;                     % Reset the node number to 1
        mID = mID+1;                      % Increase the molecule number by 1
        max_mol_node = length(cell2mat(All_Worm_Nodes_cluster(mID)));   % Set the max node number to the new molecule
        
        fprintf(fid,'%d %d %d %g %g %g\n',p_Cluster(i,1),mID,p_Cluster(i,2),p_Cluster(i,3),p_Cluster(i,4),p_Cluster(i,5));
        mol_IDs = [mol_IDs;mID]; % Save the molecule IDs for a sanity check and for future use
    end
    node_num = node_num+1;  % Increase the node number by 1
end

fprintf(fid,'Bonds\n\n');                   % print the bond types
% WLC bID, bType, Atom1, Atom2
for i=1:length(bd_lst_cluster_bonds(:,1)) 
    fprintf(fid,'%d %d %d %d\n',bd_lst_cluster_bonds(i,1),bd_lst_cluster_bonds(i,2),bd_lst_cluster_bonds(i,3),bd_lst_cluster_bonds(i,4)); 
end
fprintf(fid,'\n');

fprintf(fid,'Angles\n\n');                  % print the angle types
% angleID, aType, atom1,2,3
for i=1:length(ang_lst_cluster(:,1)) %loop for each worm
    fprintf(fid,'%d %d %d %d %d\n',ang_lst_cluster(i,1),ang_lst_cluster(i,2),ang_lst_cluster(i,3),ang_lst_cluster(i,4),ang_lst_cluster(i,5)); %Angle type needs to change
end
fprintf(fid,'\n');
fclose(fid);    % close the topology file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Create Simulation Input File
name='in.lmp4fiber_connected'     %Crease the new simulation input file
fid = fopen(name,'w+');
fprintf(fid,'# lammps simulation for Fiber Network\n');     % Title for ease of use
fprintf(fid,'units           lj\n');              
fprintf(fid,'atom_style      molecular\n');
fprintf(fid,'atom_modify     first Branch\n');              % Set the general parameters  for lammps simulations
fprintf(fid,'dimension       3\n');
fprintf(fid,'boundary        f f f\n');                     % Solid bariers are prefered at this time (no periodic)
fprintf(fid,'lattice         sc 5.0\n');
fprintf(fid,'region          box block 0 200 0 200 0 200 units lattice\n');
fprintf(fid,'\n');

fprintf(fid,'bond_style      wlc/pow\n');           %Set Bond and angle types
fprintf(fid,'angle_style     cosine\n');
fprintf(fid,'\n');
fprintf(fid,'read_data       in.worm_net_connected\n');       %read the Topology file
fprintf(fid,'\n');

%Print the groups in the sim input file
fprintf(fid,'group   nonBranch type 1\n');      % Set and print the group types
fprintf(fid,'group   Branch type 2\n');
%fprintf(fid,'group   Water type 3\n');

%for i = 1: length(Group_List)                  % If the fiber groups are required, use this
%    group_nodes = cell2mat(Group_List(i));
%    group_name = ['Fiber',num2str(i)];
%    fprintf(fid,['group ',group_name,' id ',num2str(group_nodes'),'\n']);
%end    
fprintf(fid,'\n');

fprintf(fid,'neighbor        0.5 bin\n');      %Set Neighbor values
fprintf(fid,'neigh_modify    delay 0 every 1 check yes\n');
fprintf(fid,'#neigh_modify exclude group  nonBranch nonBranch\n'); % if you don't want them to interact, uncheck these
fprintf(fid,'#neigh_modify exclude group  nonBranch Branch\n');
fprintf(fid,'comm_modify cutoff 20\n');
fprintf(fid,'\n');

fprintf(fid,'pair_style lj/cut 10\n');           %Set Pairwise interactions
fprintf(fid,'pair_coeff 1 1 1e-15 1.5 1.5\n');
fprintf(fid,'pair_coeff 1 2 1e-15 1.5 1.5\n');   %If desired, these could be different for each fiber
fprintf(fid,'pair_coeff 2 2 1e-4 1.5\n');        % it's more work but may make a difference
%fprintf(fid,'pair_coeff 3 * 1e-15 3 3\n');
fprintf(fid,'\n');

fprintf(fid,['timestep        ',num2str(Time_Step),'\n']);                 % Set Timestep (Should be stable when in the hudreths space)
fprintf(fid,'fix             1 all nve\n');             % Set Fix conditions
fprintf(fid,'fix             2 all viscous 0.00001\n');   % Remove viscus term if working with temperature/ velocity sets
fprintf(fid,'\n');
fprintf(fid,'#Possible options for movement\n');
fprintf(fid,'fix             3 all wall/reflect xlo EDGE xhi EDGE\n');  % Place walls at the edges of the sim space
fprintf(fid,'fix             4 all wall/reflect ylo EDGE yhi EDGE\n');
fprintf(fid,'fix             5 all wall/reflect zlo EDGE zhi EDGE\n');  % possible Wall options and movement
fprintf(fid,'\n');

%fprintf(fid,['velocity      all     create     ', num2str(T),'     1417\n']); %Set the temperature of the sim with random seed

% Options for moving the walls
%fprintf(fid,'variable ramp equal vdisplace(0,0.03)\n');
%fprintf(fid,'fix            6 all wall/lj126 xlo v_ramp 1.0 2.5 2.4\n');
%fprintf(fid,'variable ramp equal vdisplace(0,0.03)\n');
%fprintf(fid,'fix            7 all wall/lj126 ylo v_ramp 1.0 2.5 2.4\n');
%fprintf(fid,'variable ramp equal vdisplace(0,0.03)\n');
%fprintf(fid,'fix            8 all wall/lj126 zlo v_ramp 1.0 2.5 2.4\n');
%fprintf(fid,'\n');
%fprintf(fid,'#variable wiggle equal cwiggle(100,200.0,1000)\n');
%fprintf(fid,'#fix            6 all wall/lj126 xlo v_wiggle .1 2.0 1.5\n');
%fprintf(fid,'#variable wiggle equal cwiggle(0,250.0,1000)\n');
%fprintf(fid,'#fix            7 all wall/lj126 ylo v_wiggle .1 2.0 1.5\n');
%fprintf(fid,'#fix            8 all wall/lj126 ylo v_wiggle 1.0 1.0 2.5\n');
%fprintf(fid,'\n');

% Options for moving the atoms
%fprintf(fid,'#Force addition to groups\n');
%fprintf(fid,'#fix             9 nonBranch addforce 0  0   0.0015546269651157256\n');
%fprintf(fid,'#fix             10 nonBranch addforce 0 0.0015546269651157256   0\n');
%fprintf(fid,'\n');

fprintf(fid,'#Generate Dump Files For Sim\n');          %Allow for the output file generation 
fprintf(fid,['dump           1 all xyz ',num2str(Runs_Per_Dump),' dump.network_connected.xyz\n']);
fprintf(fid,['dump           2 all custom ',num2str(Runs_Per_Dump),' dump.network_connected.force id fx fy fz\n']);
fprintf(fid,['dump           3 all custom ',num2str(Runs_Per_Dump),' dump.network_connected.vel id vx vy vz\n']);
fprintf(fid,'\n');

fprintf(fid,['run    ',num2str(Runs),'\n']);
fprintf(fid,'\n');
%fprintf(fid,['velocity      Water     create     ', num2str(T/10),'     1417\n']);
%fprintf(fid,'\n');
%fprintf(fid,'run    1000000\n');
%fprintf(fid,'\n');
fprintf(fid,'dump           4 all xyz 1 dump.final_network_connected.xyz\n'); % THIS IS REQUIRED TO USE THE FILE READER
fprintf(fid,'\n');
fprintf(fid,'run    1\n');
fclose(fid);